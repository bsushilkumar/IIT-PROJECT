/*
 *  Note-  "single_" and "two_" and "three_" attached to variable and methods have specific meaning.
 *          Comparator Frame contain two Tab. 
 *          1. Single File Statistics. 
 *          2. Two File Comparison By Train.
 *          3. Two File Comparison By Station.
 *
 *           @All component name functionality attached to "single file comparison" tab starts with "single_".
 *           @All component name functionality attached to "two file comparison" tab starts with "two_".
 *           @All component name functionality attached to "three file comparison" tab starts with "three_".
 * 
 */
package comparator;

import static comparator.Comparator.three_CheckBox;
import static comparator.Comparator.three_StationComboBox;
import static comparator.Comparator.two_TextArea;
import static comparator.StationName.stationName;
import static comparator.TrainAndLoopNumberSorting.two_TrainList_File2;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeSet;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class Comparator {
	/*
	 * @All components from comparator are declared here.
	 */
	/*
	 * @Declaring JFrame 
	 */
	public JFrame comparatorFrame;
	/*
	 * @Declaring JPanel.
	 * @Used four JPanel for each tab. 
	 * 
	 */
	private JPanel singleFileComparision,twoFileComparison,threeFileComparison,help;
	/*
	 * @Declaring JTabbedPane.
	 */
    private JTabbedPane tp;
    /*
     * @Declaring JButtons used in all tab like search
     */
    private JButton single_FileButton,single_SearchButton,two_FileButton1,two_FileButton2,two_CompareButton,three_FileButton1,three_FileButton2,three_Compare;
    public static JComboBox single_TimeComboBox,two_TimeComboBox,three_TimeComboBox;
    public static JComboBox two_TrainList,three_StationComboBox;
    public  static JTextArea single_TextArea ,two_TextArea,help_TextArea,three_TextArea;
    private JLabel single_FilePathLabel,single_TimeComboBoxLabel,two_FilePath1Label,two_FilePath2Label,two_TimeComboBoxLabel,two_TrainListLabel,three_FilePath1Label,three_FilePath2Label,three_TimeComoboBoxLabel,three_StationComboBoxLabel;
    private String[] time = {" ","0","6", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55" };
    private JScrollPane single_Scroll,two_scroll,three_Scroll;
	public  static ArrayList<String[]> single_ArrayListFile,two_ArrayListFile1,two_ArrayListFile2,three_ArrayListFile1,three_ArrayListFile2;
	public static TreeSet loopNumber;
	public  static TreeSet trainNumber;
	public static JCheckBox single_CheckBox,two_CheckBox,three_CheckBox;
	private JRadioButton by_Departure,by_Arrival,by_Train,by_Station,three_Arrival,three_Departure;
	private ButtonGroup two_group,single_group,three_group;
	private String two_path,three_path;
	public static String single_Path_For_Station_File=null,two_Path_For_Station_File=null,three_Path_For_Station_File=null,single_fileFeedback="",two_fileFeedback="",three_fileFeedback="";
	
    /*
     * @Constructor
     */
    public Comparator() {
		super();
		this.addComponent();
		
		new Help();
		/*
		 * @ Adding listener to single_FileButton present in "single file comparison" Tab window. 
		 */
		single_FileButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				single_TextArea.setText("");
				single_FilePathLabel.setText("Select File . . .");
				single_TimeComboBox.setEnabled(false);
				single_TimeComboBox.setSelectedIndex(0);
				single_CheckBox.setForeground(Color.BLACK);
				single_CheckBox.setText("Station Name");
				single_CheckBox.setSelected(false);
				by_Train.setEnabled(false);
				by_Station.setEnabled(false);
				File selectedFile;
				JFileChooser fileChooser = new JFileChooser();
				int result = fileChooser.showOpenDialog(comparatorFrame);
				if (result == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
					single_FilePathLabel.setText(selectedFile.getAbsolutePath());
                      single_Path_For_Station_File=selectedFile.getParent();
					
						System.out.println("$$$$$$$$$$$$"+selectedFile.getParent());
						System.out.println("$$$$$$$$$$$$"+selectedFile.getAbsolutePath());
					
			//		System.out.println("Inside Comparator/ File Size-->"+selectedFile.length());
						single_CheckBox.setEnabled(true);
						single_TimeComboBox.setEnabled(true);
					single_TimeComboBox.setSelectedIndex(2);
					by_Train.setEnabled(true);
					by_Station.setEnabled(true);
					
					new FileReading().singleFileReading(selectedFile);
			
					
				}
			}
			
		});
		
		single_CheckBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					
				if(!(single_CheckBox.isSelected())) {
					single_CheckBox.setForeground(Color.BLACK);
					single_CheckBox.setText("Station Name");
				single_fileFeedback=" ";
				}
				if(single_CheckBox.isSelected())
				{
				single_fileFeedback=new StationName().findStationFile(single_Path_For_Station_File,1);
				//System.out.println("FeedBack in Comparator--"+feedback);
				}
				
			}
		});
		
		
		two_CheckBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(!(two_CheckBox.isSelected())) {
					two_CheckBox.setForeground(Color.BLACK);
					two_CheckBox.setText("Station Name");
				two_fileFeedback=" ";
				}
				if(two_CheckBox.isSelected())
				{
				two_fileFeedback=new StationName().findStationFile(two_Path_For_Station_File,2);
				//System.out.println("FeedBack in Comparator--"+feedback);
				}
				
			}
		});
		
		three_CheckBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(!(three_CheckBox.isSelected())) {
					three_CheckBox.setForeground(Color.BLACK);
					three_CheckBox.setText("Station Name");
				three_fileFeedback=" ";
				}
				if(three_CheckBox.isSelected())
				{
					three_fileFeedback=new StationName().findStationFile(three_Path_For_Station_File,3);
				//System.out.println("FeedBack in Comparator--"+feedback);
					if(three_fileFeedback.equals("FileFound"))
						{
						three_CheckBox.setEnabled(false);
						}				
				}
				
			}
		});
		
		/*
		 * @ Adding Listener to two_FileButton1 present in "two file comparison" tab 
		 */
		
		two_FileButton1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				two_TextArea.setText("");
				two_FilePath1Label.setText("Select File-1 . . .");
				two_FilePath2Label.setText("Select File-2 . . .");
				two_TimeComboBox.setEnabled(false);
				two_TrainList.setEnabled(false);
				two_TrainList.removeAllItems();
				by_Arrival.setEnabled(false);
				by_Departure.setEnabled(false);
				two_CheckBox.setForeground(Color.BLACK);
				two_CheckBox.setSelected(false);
				two_CheckBox.setEnabled(false);
				two_CheckBox.setText("Station Name");
				two_TimeComboBox.setSelectedIndex(0);
				File selectedFile;
				JFileChooser fileChooser = new JFileChooser();
				int result = fileChooser.showOpenDialog(comparatorFrame);
				if (result == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
					two_FilePath1Label.setText(selectedFile.getAbsolutePath());
					two_path=selectedFile.getParent();
					two_Path_For_Station_File=selectedFile.getParent();
					System.out.println("Inside Comparator/ File Size-->"+selectedFile.length());
					
					new FileReading().twoFileReading(selectedFile,1);
			
					
				}
				
			}
		});
		
		
		/*
		 * @ Adding Listener to two_FileButton2 present in "two file comparison" tab 
		 */
		
		two_FileButton2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(two_FilePath1Label.getText().equals("Select File-1 . . ."))
				{
					JOptionPane.showMessageDialog(comparatorFrame, "Select File-1 ");
				}else {
					two_CheckBox.setForeground(Color.BLACK);
					two_CheckBox.setSelected(false);
					two_CheckBox.setText("Station Name");
					
				File selectedFile;
				JFileChooser fileChooser = new JFileChooser(new File(two_path));
				int result = fileChooser.showOpenDialog(comparatorFrame);
				if (result == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
					two_FilePath2Label.setText(selectedFile.getAbsolutePath());
					two_TimeComboBox.setEnabled(true);
					two_TimeComboBox.setSelectedIndex(2);
					two_CheckBox.setEnabled(true);
					System.out.println("Inside Comparator/ File Size-->"+selectedFile.length());
					by_Arrival.setEnabled(true);
					by_Departure.setEnabled(true);
					
					new FileReading().twoFileReading(selectedFile,2);
			
				}
				}
				
			}
		});
		
		three_FileButton1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				three_TextArea.setText("");
				three_FilePath1Label.setText("Select File-1 . . .");
				three_FilePath2Label.setText("Select File-2 . . .");
				three_TimeComboBox.setEnabled(false);
			    three_TimeComboBox.setSelectedIndex(0);
				three_StationComboBox.setEnabled(false);
				three_StationComboBox.removeAllItems();
				three_Arrival.setEnabled(false);
				three_Departure.setEnabled(false);
				three_CheckBox.setForeground(Color.BLACK);
				three_CheckBox.setSelected(false);
				three_CheckBox.setText("Station Name");
				three_fileFeedback="";
				
				File selectedFile;
				JFileChooser fileChooser = new JFileChooser();
				int result = fileChooser.showOpenDialog(comparatorFrame);
				if (result == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
					three_FilePath1Label.setText(selectedFile.getAbsolutePath());
					three_path=selectedFile.getParent();
					three_Path_For_Station_File=selectedFile.getParent();
					System.out.println("Inside Comparator/ File Size-->"+selectedFile.length());
					three_CheckBox.setEnabled(true);
					
					new FileReading().threeFileReading(selectedFile,1);
			
					
				}
				
				
				
				
				
			}
		});
		
		three_FileButton2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(three_FilePath1Label.getText().equals("Select File-1 . . ."))
				{
					JOptionPane.showMessageDialog(comparatorFrame, "Select File-1 ");
				}else {
					
					
				File selectedFile;
				JFileChooser fileChooser = new JFileChooser(new File(three_path));
				int result = fileChooser.showOpenDialog(comparatorFrame);
				if (result == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
					three_FilePath2Label.setText(selectedFile.getAbsolutePath());
					three_TimeComboBox.setEnabled(true);
					three_TimeComboBox.setSelectedIndex(2);
				     three_Arrival.setEnabled(true);
				     three_Departure.setEnabled(true);
				     	
						if(three_fileFeedback.equals("FileNotFound"))
						{
							three_CheckBox.setForeground(Color.BLACK);
							three_CheckBox.setSelected(false);
							three_CheckBox.setText("Station Name");
					
						}
						three_CheckBox.setEnabled(false);
					new FileReading().threeFileReading(selectedFile,2);
			
				}
				}
				
			}
		});
		
		single_SearchButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent arg0) {
				
				if(single_FilePathLabel.getText().equals("Select File . . ."))
				{
					JOptionPane.showMessageDialog(comparatorFrame, "Select File ");
				}else {
					
					if(by_Train.isSelected())
					{
				single_TextArea.setText("");
				new FileReading().single_Search_ByTrain();
					}
					if(by_Station.isSelected())
					{
						single_TextArea.setText("");
						
						new FileReading().single_Search_ByStation();
					}
			}
			}
		});
		
		
		
		two_CompareButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
			     if(two_FilePath1Label.getText(). equals("Select File-1 . . ."))
			     {
			    	 JOptionPane.showMessageDialog(comparatorFrame, "Select File-1 ");
			     }
			     else {
			    	 if(two_FilePath2Label.getText().equals("Select File-2 . . ."))
				     {
				    	 JOptionPane.showMessageDialog(comparatorFrame, "Select File-2 ");
				     }
			    	 else {
			    		 if(two_TrainList_File2.contains(two_TrainList.getSelectedItem()))
			   		  {
			    			 two_TextArea.setText("");
			    			// JOptionPane.showMessageDialog(comparatorFrame, "Clear Text");
			    			 
			    			if(by_Departure.isSelected())
			    			{
			    			 new FileReading().two_Compare_ByDeparture();  
			    			}
			    			if(by_Arrival.isSelected())
			    			{
			    				new FileReading().two_Compare_ByArrival();
			    			}
			   		  }
			   		  else {
			   			  JOptionPane.showMessageDialog(comparatorFrame, "Train Not present in File-2");
			   		  }
			   	
			     		
			    		 
			    	 }
			     }
			     
				
			}
		});
		
		
		
		three_Compare.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
			     if(three_FilePath1Label.getText(). equals("Select File-1 . . ."))
			     {
			    	 JOptionPane.showMessageDialog(comparatorFrame, "Select File-1 ");
			     }
			     else {
			    	 if(three_FilePath2Label.getText().equals("Select File-2 . . ."))
				     {
				    	 JOptionPane.showMessageDialog(comparatorFrame, "Select File-2 ");
				     }
			    	 else {
			    		 String comboSelectedStation=(String)three_StationComboBox.getSelectedItem();
					 if(three_CheckBox.isSelected())
					 {
						  System.out.println("################## Inside if at Compare Button");
						 for (Integer o : stationName.keySet()) {
						      if (stationName.get(o).equals((String)three_StationComboBox.getSelectedItem())) {
						    	  comboSelectedStation= o.toString();
						    	  if (comboSelectedStation.length() == 1) {
						    		  comboSelectedStation="00"+comboSelectedStation;
						    		  //	System.out.println("After substring " + loop1);
									}
						    	  if (comboSelectedStation.length() == 2) {
						    		  comboSelectedStation="0"+comboSelectedStation;
						    		  //	System.out.println("After substring " + loop1);
									}
						    	 
						    	  System.out.println("Final Key + Length--------->"+comboSelectedStation+"  / "+comboSelectedStation.length());
						    	  break;
						      }
					 }
					 }
			    		 if(TrainAndLoopNumberSorting.three_StationFile2.contains(comboSelectedStation))
			   		  {      
			    			 three_TextArea.setText("");
			    			// JOptionPane.showMessageDialog(comparatorFrame, "Clear Text");
			    			 if(three_Arrival.isSelected())
			    			 {
			    				 new FileReading().three_Compare(1); 
			    			 }
			    			 if(three_Departure.isSelected())
			    			 {
			    				 new FileReading().three_Compare(2);	 
			    			 }
			    		
			    				
			    			
			   		  }
			   		  else {
			   			  JOptionPane.showMessageDialog(comparatorFrame, "Station Not present in File-2");
			   		  }
			   	
			     		
			    		 
			    	 }
			     }
			     
				
				
				
			}
		});
	
	}

	/*
	 * @Adding Component to Comparator Frame.
	 */
	void addComponent()
	{
        comparatorFrame=new JFrame("Comparator");
        
		
		/*
		 *@ Component present in Single File Comparision Tab. 
		 */
		single_FileButton=new JButton("File");
		single_FilePathLabel=new JLabel("Select File . . .");
		single_CheckBox=new JCheckBox("Station Name");
		single_CheckBox.setEnabled(false);
		single_TimeComboBoxLabel=new JLabel("Halt Time Difference. (In Minutes)");
		single_SearchButton=new JButton("Search");
		single_TimeComboBox=new JComboBox(time);
		single_TimeComboBox.setEnabled(false);
		single_group=new ButtonGroup();
		by_Train=new JRadioButton("Trains",true);
		by_Train.setEnabled(false);
		by_Station=new JRadioButton("Stations");
		by_Station.setEnabled(false);
		single_group.add(by_Train);
		single_group.add(by_Station);
		
		single_TextArea=new JTextArea();
		single_TextArea.setFont(single_TextArea.getFont().deriveFont(16f));
		single_Scroll=new JScrollPane(single_TextArea ,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			
		singleFileComparision=new JPanel();
		singleFileComparision.setLayout(null);
		singleFileComparision.add(single_FileButton);
		singleFileComparision.add(single_FilePathLabel);
		singleFileComparision.add(single_CheckBox);
		singleFileComparision.add(single_TimeComboBoxLabel);
		singleFileComparision.add(single_TimeComboBox);
		singleFileComparision.add(by_Station);
		singleFileComparision.add(by_Train);
		singleFileComparision.add(single_SearchButton);
		singleFileComparision.add(single_Scroll);
		
		single_FileButton.setBounds(30, 30, 100, 40);
		single_FilePathLabel.setBounds(150, 30, 1000, 40);
		single_CheckBox.setBounds(1200, 30, 120, 40);
		single_TimeComboBoxLabel.setBounds(30, 130, 200, 40);
		single_TimeComboBox.setBounds(240, 136, 160, 30);
		by_Train.setBounds(520, 130, 100, 40);
		by_Station.setBounds(630, 130, 100, 40);
		single_SearchButton.setBounds(860, 130, 100, 40);
		single_Scroll.setBounds(30, 190, 1285, 450);
		
		
		/*
		 * @Component present in Two File Comparision Tab.
		 */
		two_FileButton1=new JButton("File-1");
		two_FilePath1Label=new JLabel("Select File-1 . . .");
		two_FileButton2=new JButton("File-2");
		two_FilePath2Label=new JLabel("Select File-2 . . .");
		two_CheckBox=new JCheckBox("Station Name");
		two_CheckBox.setEnabled(false);
		two_TimeComboBoxLabel=new JLabel(" Time Difference. (In Minutes)");                
		two_TimeComboBox=new JComboBox(time);
		two_TimeComboBox.setEnabled(false);
		two_TrainListLabel=new JLabel("Train List From File-1");
		two_TrainList=new JComboBox<>();
		two_TrainList.setEnabled(false);
		two_CompareButton=new JButton("Compare");
	    two_TextArea=new JTextArea();
	    two_TextArea.setFont(two_TextArea.getFont().deriveFont(16f));
		two_scroll=new JScrollPane(two_TextArea ,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        two_group=new ButtonGroup();
        by_Arrival=new JRadioButton("Arrival");
        by_Arrival.setEnabled(false);
        by_Departure=new JRadioButton("Departure",true);
        by_Departure.setEnabled(false);
        two_group.add(by_Arrival);
        two_group.add(by_Departure);
        
		twoFileComparison=new JPanel();
		twoFileComparison.setLayout(null);
		
		twoFileComparison.add(two_FileButton1);
		twoFileComparison.add(two_FilePath1Label);
		twoFileComparison.add(two_FileButton2);
		twoFileComparison.add(two_FilePath2Label);
		twoFileComparison.add(two_CheckBox);
		twoFileComparison.add(two_TimeComboBoxLabel);
		twoFileComparison.add(two_TimeComboBox);
		twoFileComparison.add(two_TrainListLabel);
		twoFileComparison.add(two_TrainList);
		twoFileComparison.add(two_CompareButton);
		twoFileComparison.add(two_scroll);
		twoFileComparison.add(by_Arrival);
		twoFileComparison.add(by_Departure);
		
		two_FileButton1.setBounds(30, 30, 100, 40);
		two_FilePath1Label.setBounds(150, 30, 500, 40);
		two_FileButton2.setBounds(700, 30, 100, 40);
		two_FilePath2Label.setBounds(820, 30, 500, 40);
		two_CheckBox.setBounds(1200, 30, 120, 40);
		two_TimeComboBoxLabel.setBounds(30, 130, 230, 40);
		two_TimeComboBox.setBounds(210, 136, 160, 30);
		two_TrainListLabel.setBounds(450, 130, 120, 40);
		two_TrainList.setBounds(580,136,160,30);
		two_CompareButton.setBounds(1100, 130, 100, 40);
		two_scroll.setBounds(30, 190, 1285, 450);
		by_Arrival.setBounds(800, 130, 100, 40);
		by_Departure.setBounds(900, 130, 100, 40);
		
	    three_FileButton1=new JButton("File-1");
	    three_FilePath1Label=new JLabel("Select File-1 . . .");
	    three_FileButton2=new JButton("File-2");
	    three_FilePath2Label=new JLabel("Select File-2 . . .");
	    three_CheckBox=new JCheckBox("Station Name");
		three_CheckBox.setEnabled(false);
	    three_TimeComoboBoxLabel=new JLabel("Time Difference. (In Minutes)");
	    three_TimeComboBox=new JComboBox<>(time);
	    three_TimeComboBox.setEnabled(false);
	    three_StationComboBoxLabel=new JLabel("Common Stations From Both File");
	    three_StationComboBox=new JComboBox<>();
	    three_StationComboBox.setEnabled(false);
		three_Compare=new JButton("Compare");
		three_TextArea=new JTextArea();
		three_TextArea.setFont(three_TextArea.getFont().deriveFont(16f));
		three_Scroll=new JScrollPane(three_TextArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	    three_group=new ButtonGroup();
	    three_Arrival=new JRadioButton("Arrival");
	    three_Arrival.setEnabled(false);
	    three_Departure=new JRadioButton("Departure",true);
	    three_Departure.setEnabled(false);
	    three_group.add(three_Arrival);
	    three_group.add(three_Departure);
	    
		threeFileComparison=new JPanel();
	    threeFileComparison.setLayout(null);
		
	    threeFileComparison.add(three_FileButton1);
	    threeFileComparison.add(three_FilePath1Label);
	    threeFileComparison.add(three_FileButton2);
	    threeFileComparison.add(three_FilePath2Label);
	    threeFileComparison.add(three_CheckBox);
	    threeFileComparison.add(three_TimeComoboBoxLabel);
	    threeFileComparison.add(three_TimeComboBox);
	    threeFileComparison.add(three_StationComboBoxLabel);
	    threeFileComparison.add(three_StationComboBox);
	    threeFileComparison.add(three_Compare);
	    threeFileComparison.add(three_Scroll);
	    threeFileComparison.add(three_Arrival);
	    threeFileComparison.add(three_Departure);
	    
	    
	    
	    three_FileButton1.setBounds(30, 30, 100, 40);
		three_FilePath1Label.setBounds(150, 30, 500,+ 40);
		three_FileButton2.setBounds(700, 30, 100, 40);
		three_FilePath2Label.setBounds(820, 30, 500, 40);
		three_CheckBox.setBounds(1200, 30, 120, 40);
		three_TimeComoboBoxLabel.setBounds(30, 130, 230, 40);
		three_TimeComboBox.setBounds(210, 136, 160, 30);
		three_StationComboBoxLabel.setBounds(385, 130, 190, 40);
		three_StationComboBox.setBounds(580,136,160,30);
		three_Compare.setBounds(1100, 130, 100, 40);
		three_Scroll.setBounds(30, 190, 1285, 450);
		three_Arrival.setBounds(800, 130, 100, 40);
		three_Departure.setBounds(900, 130, 100, 40);
	    
	    
	  /*  three_FileButton1.setBounds(30, 30, 100, 40);
	    three_FilePath1Label.setBounds(150, 30, 500, 40);
	    three_FileButton2.setBounds(700, 30, 100, 40);
	    three_FilePath2Label.setBounds(820, 30, 500, 40);
	    three_StationComboBoxLabel.setBounds(30, 150, 120, 40);
	    three_StationComboBox.setBounds(150, 154, 180, 30);
	    three_Compare.setBounds(400, 150, 100, 40);
	    three_ScrollFile1.setBounds(30, 260, 610, 380);
	    three_ScrollFile2.setBounds(690, 260, 610, 380);
	    
	*/	
		help_TextArea=new JTextArea();
		help_TextArea.setEditable(false);
		help_TextArea.setBackground(new Color(255,	250	,250) );
		help_TextArea.setBounds(10, 10, 1300, 630);
		
		help=new JPanel();
		help.setLayout(null);
		help.add(help_TextArea);
		tp=new JTabbedPane();
		tp.setBounds(10, 0, 1335, 680);
		tp.addTab("Single File Satistics", singleFileComparision);
		tp.addTab("Two File Comparison By Train ", twoFileComparison);
		tp.addTab("Two File Comparison By Station", threeFileComparison);
		tp.addTab("Help", help);
		comparatorFrame.add(tp);
		comparatorFrame.setSize(1370, 730);
		comparatorFrame.setLayout(null);
		comparatorFrame.setVisible(true);
	}
	public static void main(String[] args) {
		new Comparator();

	}

}
