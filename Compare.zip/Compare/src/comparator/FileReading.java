package comparator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import  static comparator.TrainAndLoopNumberSorting.two_Station_Number;
import static comparator.StationName.stationName;
import static comparator.Comparator.*;


public class FileReading {

	private String csvSplitBy = "\\s+";
	private BufferedReader file1Buffer = null;
	private String lineFile1 = "";
	private String[] file1String, file2String;

	public void singleFileReading(File selectedFile) {
		try {
			single_ArrayListFile = new ArrayList<String[]>();

			System.out.println("single_ArrayListFile Creation" + single_ArrayListFile.size());
			file1Buffer = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
			while ((lineFile1 = file1Buffer.readLine()) != null) {
				// use space as separator
				String[] lineRecord = lineFile1.split(csvSplitBy);
				single_ArrayListFile.add(lineRecord);

			}
			String name = selectedFile.getName();
			System.out.println(name.substring(name.lastIndexOf(".") + 1));
			if ((name.substring(name.lastIndexOf(".") + 1)).equals("txt")) {
				single_ArrayListFile.remove(0);
			}

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (file1Buffer != null) {
				try {
					file1Buffer.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}

		/*
		 * @ calling Train_And_Loop_Number_Sorting() method Present in
		 * TrainAndLoopNumberSorting class to find Train number and loop number from
		 * file and sorting them into ascending order.
		 */

		System.out.println("All data InArray");

		new TrainAndLoopNumberSorting().single_Train_And_Loop_Number_Sorting();

	}

	public void twoFileReading(File selectedFile, int number) {

		if (number == 1) {
			try {
				two_ArrayListFile1 = new ArrayList<String[]>();

				// System.out.println("single_ArrayListFile
				// Creation"+two_ArrayListFile1.size());
				file1Buffer = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
				while ((lineFile1 = file1Buffer.readLine()) != null) {
					// use space as separator
					String[] lineRecord = lineFile1.split(csvSplitBy);
					two_ArrayListFile1.add(lineRecord);
				}

				String name = selectedFile.getName();
				// System.out.println(name.substring(name.lastIndexOf(".")+1));
				if ((name.substring(name.lastIndexOf(".") + 1)).equals("txt")) {
					two_ArrayListFile1.remove(0);
				}
				System.out.println(" file-1 ArrayFileSize in FileReading " + two_ArrayListFile1.size());

			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (file1Buffer != null) {
					try {
						file1Buffer.close();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
			}

			/*
			 * @ calling Train_And_Loop_Number_Sorting() method Present in
			 * TrainAndLoopNumberSorting class to find Train number and loop number from
			 * file and sorting them into ascending order.
			 */

			new TrainAndLoopNumberSorting().two_Train_And_Loop_Number_Sorting(1);

		}
		if (number == 2) {
			try {
				two_ArrayListFile2 = new ArrayList<String[]>();

				// System.out.println("single_ArrayListFile
				// Creation"+two_ArrayListFile2.size());
				file1Buffer = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
				while ((lineFile1 = file1Buffer.readLine()) != null) {
					// use space as separator
					String[] lineRecord = lineFile1.split(csvSplitBy);
					two_ArrayListFile2.add(lineRecord);
				}
				String name = selectedFile.getName();
				// System.out.println(name.substring(name.lastIndexOf(".")+1));
				if ((name.substring(name.lastIndexOf(".") + 1)).equals("txt")) {
					two_ArrayListFile2.remove(0);
				}

				System.out.println(" file-2 ArrayFileSize in FileReading " + two_ArrayListFile2.size());

			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (file1Buffer != null) {
					try {
						file1Buffer.close();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
			}

			/*
			 * @ calling Train_And_Loop_Number_Sorting() method Present in
			 * TrainAndLoopNumberSorting class to find Train number and loop number from
			 * file and sorting them into ascending order.
			 */

			new TrainAndLoopNumberSorting().two_Train_And_Loop_Number_Sorting(2);

		}

	}

	
	public void threeFileReading(File selectedFile, int number)
	{
		if (number == 1) {
			try {
				three_ArrayListFile1 = new ArrayList<String[]>();

				// System.out.println("single_ArrayListFile
				// Creation"+two_ArrayListFile1.size());
				file1Buffer = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
				while ((lineFile1 = file1Buffer.readLine()) != null) {
					// use space as separator
					String[] lineRecord = lineFile1.split(csvSplitBy);
					three_ArrayListFile1.add(lineRecord);
				}

				String name = selectedFile.getName();
				// System.out.println(name.substring(name.lastIndexOf(".")+1));
				if ((name.substring(name.lastIndexOf(".") + 1)).equals("txt")) {
					three_ArrayListFile1.remove(0);
				}
				System.out.println(" file-1 ArrayFileSize in FileReading " + three_ArrayListFile1.size());

			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (file1Buffer != null) {
					try {
						file1Buffer.close();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
			}

			/*
			 * @ calling Train_And_Loop_Number_Sorting() method Present in
			 * TrainAndLoopNumberSorting class to find Train number and loop number from
			 * file and sorting them into ascending order.
			 */

			new TrainAndLoopNumberSorting().three_Train_And_Loop_Number_Sorting(1);

		}
		
		
		if (number == 2) {
			try {
				three_ArrayListFile2 = new ArrayList<String[]>();

				// System.out.println("single_ArrayListFile
				// Creation"+two_ArrayListFile2.size());
				file1Buffer = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
				while ((lineFile1 = file1Buffer.readLine()) != null) {
					// use space as separator
					String[] lineRecord = lineFile1.split(csvSplitBy);
					three_ArrayListFile2.add(lineRecord);
				}
				String name = selectedFile.getName();
				// System.out.println(name.substring(name.lastIndexOf(".")+1));
				if ((name.substring(name.lastIndexOf(".") + 1)).equals("txt")) {
					three_ArrayListFile2.remove(0);
				}

				System.out.println(" file-2 ArrayFileSize in FileReading " + three_ArrayListFile2.size());

			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (file1Buffer != null) {
					try {
						file1Buffer.close();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
			}

			/*
			 * @ calling Train_And_Loop_Number_Sorting() method Present in
			 * TrainAndLoopNumberSorting class to find Train number and loop number from
			 * file and sorting them into ascending order.
			 */

			new TrainAndLoopNumberSorting().three_Train_And_Loop_Number_Sorting(2);

		}
		
		
		
		
	}
	
	
	
	
	public void single_Search_ByTrain() {

		boolean flag = true;
		String resultString = null,station=null,arrival=null,departure=null;
		
		single_TextArea.append("\t\t\tAll Trains and It's Cursponding Halting Stations From File ");
		single_TextArea.append("\n\n\nTrain Number  ");
		for (int i = 0; i < 2; i++) {
			single_TextArea
					.append("\t\t" + "Station         -->  " + " Arrival Time - " + "Departure Time   " + "[Halt Time]");
		}

		int timedifference = Integer.valueOf((String) single_TimeComboBox.getSelectedItem());

		Iterator<String[]> it = single_ArrayListFile.iterator();
		while (it.hasNext()) {

			String[] strings = (String[]) it.next();

			if (!(strings[0].equals(""))) {

				for (int j = 9; j < strings.length; j += 3) {
					System.out.println("Arrval and Dept time passing to Method    Loop" + strings[j] + "  Arrival-"
							+ strings[j + 1] + "  Dept-" + strings[j + 2]);
					resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(strings[j + 1],
							strings[j + 2]);
					// resultString = new CompareAction().calculateTimeDifference(strings[j + 1],
					// strings[j + 2]);
					String[] timeResult = resultString.split(":");
					int hour = 0, minute = 0, second = 0;

					// Checking String is null or not
					if (timeResult[0].equals("0")) {
						if (timeResult[0].equals("0")) {

							hour = 0;
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);
								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}

							}

						}

						else {
							hour = Integer.parseInt(timeResult[0]);

							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

					} else {

						hour = Integer.parseInt(timeResult[0]);
						if (timeResult[1].equals("0")) {
							minute = 0;
							if (timeResult[2].equals("0")) {
								second = 0;
							}
						} else {
							minute = Integer.parseInt(timeResult[1]);

							if (timeResult[2].equals("0")) {
								second = 0;
							} else {
								second = Integer.parseInt(timeResult[2]);
							}
						}

					}
					station=strings[j];
					arrival=strings[j+1];
					departure=strings[j+2];
					
					if(single_fileFeedback.equals("FileFound"))
					{
						if (strings[j].length() == 7) {
							station = strings[j].substring(0, strings[j].length() - 4);
							
						}
						if (strings[j].length() == 6) {
							station = "0"+strings[j].substring(0, strings[j].length() - 4);
							
						}
						if (strings[j].length() == 5) {
							station = "00"+strings[j].substring(0, strings[j].length() - 4);
							
						}
						station=stationName.get(Integer.valueOf(station));
					}

					if (hour >= 0 || minute >= 0) {

						if (hour > 0) {
							if (flag) {
								single_TextArea.append("\n\n" + strings[0]);
								flag = false;
							}
							single_TextArea.append("\t\t" + station + "      --->    " + arrival + "  -  "
									+ departure + "    [" + hour + ":" + minute + ":" + second + "]" + "\t");

							// displayResultF2.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" +
							// strings[j + 2]
							// + "\t\t" + hour + ":" + minute + ":" + second + "\n");

						}
						if (minute >= timedifference && hour == 0) {
							//
							if (flag) {
								single_TextArea.append("\n\n" + strings[0]);
								flag = false;
							}
							single_TextArea.append("\t\t" + station + "      --->    " + arrival + "  -  "
									+ departure + "    [" + hour + ":" + minute + ":" + second + "]" + "\t");

							// displayResultF2.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" +
							// strings[j + 2]
							// + "\t\t" + hour + ":" + minute + ":" + second + "\n");
						}

					}

				}
				flag = true;
			}

		}
single_TextArea.setCaretPosition(0);
	}

	public void two_Compare_ByDeparture() {

		// System.out.println("##### inside two_search_button");
		boolean flag = true;
		int spaceCount=0;
		int timedifference = Integer.valueOf((String) two_TimeComboBox.getSelectedItem());
		char sign=' ';
		String station=null;
		// System.out.println("printing TimeComboBox value---"+timedifference);
		two_TextArea.setText("");
		Iterator itF1 = two_ArrayListFile1.iterator();
		Iterator itF2 = two_ArrayListFile2.iterator();
		System.out
				.println("$$$$$$$$$$$$$$$$$$$$$$$$$$" + two_ArrayListFile1.size() + "---" + two_ArrayListFile2.size());
		// System.out.println("ArrayList f1"+two_ArrayListFile1);
		// System.out.println("ArrayList f2"+two_ArrayListFile2);
		while (itF1.hasNext()) {
			String[] strings = (String[]) itF1.next();
			// System.out.println("Inside while loop of two search button-1");
			// System.out.println(strings[0].equals(two_TrainList.getSelectedItem()));
			if (strings[0].equals(two_TrainList.getSelectedItem())) {

				file1String = strings;
				// System.out.println(strings[0]);
				System.out.println("file1String length=" + file1String.length);
				for(int i=0;i<file1String.length;i++)
				{
					System.out.println("File1String *******######"+file1String[i]);
				}
				break;
			}

		}

		while (itF2.hasNext()) {
			// System.out.println("Inside while loop of two search button-2");
			String[] strings = (String[]) itF2.next();
			// System.out.println(strings[0].equals(two_TrainList.getSelectedItem()));
			if (strings[0].equals(two_TrainList.getSelectedItem())) {
				file2String = strings;
				// System.out.println(strings[0]);
				System.out.println("file2String length=" + file2String.length);
				for(int i=0;i<file2String.length;i++)
				{
					System.out.println("File2String *******######"+file2String[i]);
				}
				break;
			}

		}
		String stationFile1 = null, stationFile2 = null, resultString = null;

		for (int i = 9; i < file1String.length; i += 3) {
			System.out.println(
					"Inside first for Loop i value + length------>" + file1String[i] + "-" + file1String[i].length());
			if (file1String[i].length() == 7) {
				stationFile1 = file1String[i].substring(0, file1String[i].length() - 4);
				System.out.println("After substring " + stationFile1);
			}
			if (file1String[i].length() == 6) {
				stationFile1 = "0"+file1String[i].substring(0, file1String[i].length() - 4);
				System.out.println("After substring " + stationFile1);
			}
			if (file1String[i].length() == 5) {
				stationFile1 = "00"+file1String[i].substring(0, file1String[i].length() - 4);
				System.out.println("After substring " + stationFile1);
			}
			for (int j = 9; j < file2String.length; j += 3) {
				System.out.println("Inside second for Loop j value + length------>" + file2String[j] + "-"
						+ file2String[j].length());

				if (file2String[j].length() == 7) {
					stationFile2 = file2String[j].substring(0, file2String[j].length() - 4);
					System.out.println("After substring " + stationFile2);
				}
				if (file2String[j].length() == 6) {
					stationFile2 = "0"+file2String[j].substring(0, file2String[j].length() - 4);
					System.out.println("After substring " + stationFile2);
				}
				if (file2String[j].length() == 5) {
					stationFile2 = "00"+file2String[j].substring(0, file2String[j].length() - 4);
					System.out.println("After substring " + stationFile2);
				}

				if (stationFile1.equals(stationFile2)) {
					System.out.println("Comparision of two station (Equale or not)" + stationFile1.equals(stationFile2)
							+ "/StaionF1-=" + stationFile1 + "StationF2-" + stationFile2);
					System.out.println("Calling method to calculate time");
					System.out.print(
							"\t passing arrgument to time" + file1String[i + 2] + "---------" + file2String[j + 2]);
				//checking which is greater number.........
					
					station=stationFile1;
					if(two_fileFeedback.equals("FileFound"))
					{
						
						station=stationName.get(Integer.valueOf(station));
					}
					
					if(Integer.valueOf(file1String[i+2])<Integer.valueOf(file2String[j+2]))
					{
						resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(file1String[i + 2],
							file2String[j + 2]);
						
						String[] timeResult = resultString.split(":");
						int hour = 0, minute = 0, second = 0;

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);

								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						if (hour >= 0 || minute >= 0) {
							if (flag) {
								two_TextArea.append("\t\t\t\t\tTrain Time Comparison By Departure_Time");
								two_TextArea.append("\n\nTrain Number" + "\t\tStaion  --->    (Departure Time from File-1)    -    (Departure Time from File-2)        Time Difference[HH:MM:SS]"
									/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]"
										+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]\n"*/);
								two_TextArea.append("\n\n\n\n\n\n" + file1String[0]);
								flag = false;
							}
							
							 if(spaceCount==3)
	                         {
	                         	two_TextArea.append("\n\n");
	                         	spaceCount=0;
	                         }
							if (hour > 0) {
	                           
								spaceCount++;
								two_TextArea.append("\t\t" +"                "+/* file1String[j] */station+ "      --->    "+file1String[i+2] +" - "+file2String[j+2]+"    ( " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  " );
								sign=' ';
								

							}
							if (minute >= timedifference && hour == 0) {
								
								spaceCount++;
								two_TextArea.append("\t\t" + "               "+/*file1String[j] */station+ "      --->    "+file1String[i+2] +" - "+file2String[j+2]+"   ( " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  " );
	                                 sign=' ';
							}

						}
						
						
					}
					if(Integer.valueOf(file1String[i+2])>Integer.valueOf(file2String[j+2])) {
						resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(file2String[j + 2],file1String[i + 2]);
						sign='-';
						String[] timeResult = resultString.split(":");
						int hour = 0, minute = 0, second = 0;

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);

								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						if (hour >= 0 || minute >= 0) {
							if (flag) {
								two_TextArea.append("\t\t\t\t\tTrain Time Comparison By Departure_Time");
								two_TextArea.append("\n\nTrain Number" + "\t\tStaion  --->    (Departure Time from File-1)    -    (Departure Time from File-2)        Time Difference[HH:MM:SS]"
									/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]"
										+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]\n"*/);
								two_TextArea.append("\n\n\n\n\n\n" + file1String[0]);
								flag = false;
							}
							
							 if(spaceCount==3)
	                         {
	                         	two_TextArea.append("\n\n");
	                         	spaceCount=0;
	                         }
							if (hour > 0) {
	                           
								spaceCount++;
								two_TextArea.append("\t\t" +"                "+/* file1String[j] */station+ "      --->    "+file1String[i+2] +" - "+file2String[j+2]+"   (  " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  ");
								sign=' ';
								

							}
							if (minute >= timedifference && hour == 0) {
								
								spaceCount++;
								two_TextArea.append("\t\t" + "               "+/*file1String[j] */station+ "      --->    "+file1String[i+2] +" - "+file2String[j+2]+"    ( " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  " );
	                                 sign=' ';
							}

						}
					}
					
					
					
					
					
					//resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(file1String[i + 2],
					//		file2String[j + 2]);
					// --------------------------------------------------->
					System.out.println("Resulst after time calculation =================>>>" + resultString);
					
					// --------------------------------------------------->
					break;
				}

			}
		}
		if(two_TextArea.getText().equals(""))
		{
		two_TextArea.append("\n\n\t\t\t\t ---------------------Both File Contain Same Information--------------------");
		
		}
		//System.out.println("Size of font"+two_TextArea.getFont().getFontName());
		
		two_TextArea.setCaretPosition(0);

	}
	
	public void two_Compare_ByArrival() {
		
		
		boolean flag = true;
		int spaceCount=0;
		int timedifference = Integer.valueOf((String) two_TimeComboBox.getSelectedItem());
		char sign=' ';
		String station=null;
		// System.out.println("printing TimeComboBox value---"+timedifference);
		two_TextArea.setText("");
		Iterator itF1 = two_ArrayListFile1.iterator();
		Iterator itF2 = two_ArrayListFile2.iterator();
		System.out
				.println("$$$$$$$$$$$$$$$$$$$$$$$$$$" + two_ArrayListFile1.size() + "---" + two_ArrayListFile2.size());
		// System.out.println("ArrayList f1"+two_ArrayListFile1);
		// System.out.println("ArrayList f2"+two_ArrayListFile2);
		while (itF1.hasNext()) {
			String[] strings = (String[]) itF1.next();
			// System.out.println("Inside while loop of two search button-1");
			// System.out.println(strings[0].equals(two_TrainList.getSelectedItem()));
			if (strings[0].equals(two_TrainList.getSelectedItem())) {

				file1String = strings;
				// System.out.println(strings[0]);
				System.out.println("file1String length=" + file1String.length);
				for(int i=0;i<file1String.length;i++)
				{
					System.out.println("File1String *******######"+file1String[i]);
				}
				break;
			}

		}

		while (itF2.hasNext()) {
			// System.out.println("Inside while loop of two search button-2");
			String[] strings = (String[]) itF2.next();
			// System.out.println(strings[0].equals(two_TrainList.getSelectedItem()));
			if (strings[0].equals(two_TrainList.getSelectedItem())) {
				file2String = strings;
				// System.out.println(strings[0]);
				System.out.println("file2String length=" + file2String.length);
				for(int i=0;i<file2String.length;i++)
				{
					System.out.println("File2String *******######"+file2String[i]);
				}
				break;
			}

		}
		String stationFile1 = null, stationFile2 = null, resultString = null;

		for (int i = 9; i < file1String.length; i += 3) {
			System.out.println(
					"Inside first for Loop i value + length------>" + file1String[i] + "-" + file1String[i].length());
			if (file1String[i].length() == 7) {
				stationFile1 = file1String[i].substring(0, file1String[i].length() - 4);
				System.out.println("After substring " + stationFile1);
			}
			if (file1String[i].length() == 6) {
				stationFile1 = "0"+file1String[i].substring(0, file1String[i].length() - 4);
				System.out.println("After substring " + stationFile1);
			}
			if (file1String[i].length() == 5) {
				stationFile1 = "00"+file1String[i].substring(0, file1String[i].length() - 4);
				System.out.println("After substring " + stationFile1);
			}
			for (int j = 9; j < file2String.length; j += 3) {
				System.out.println("Inside second for Loop j value + length------>" + file2String[j] + "-"
						+ file2String[j].length());

				if (file2String[j].length() == 7) {
					stationFile2 = file2String[j].substring(0, file2String[j].length() - 4);
					System.out.println("After substring " + stationFile2);
				}
				if (file2String[j].length() == 6) {
					stationFile2 = "0"+file2String[j].substring(0, file2String[j].length() - 4);
					System.out.println("After substring " + stationFile2);
				}
				if (file2String[j].length() == 5) {
					stationFile2 = "00"+file2String[j].substring(0, file2String[j].length() - 4);
					System.out.println("After substring " + stationFile2);
				}

				if (stationFile1.equals(stationFile2)) {
					System.out.println("Comparision of two station (Equale or not)" + stationFile1.equals(stationFile2)
							+ "/StaionF1-=" + stationFile1 + "StationF2-" + stationFile2);
					System.out.println("Calling method to calculate time");
					System.out.print(
							"\t passing arrgument to time" + file1String[i + 2] + "---------" + file2String[j + 2]);
				//checking which is greater number.........
					station=stationFile1;
					if(two_fileFeedback.equals("FileFound"))
					{
						
						station=stationName.get(Integer.valueOf(station));
					}
					
					
					if(Integer.valueOf(file1String[i+1])<Integer.valueOf(file2String[j+1]))
					{
						resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(file1String[i + 1],
							file2String[j + 1]);
						
						String[] timeResult = resultString.split(":");
						int hour = 0, minute = 0, second = 0;

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);

								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						
						if (hour >= 0 || minute >= 0) {
							if (flag) {
								two_TextArea.append("\t\t\t\t\tTrain Time Comparison By Arrival_Time");
								two_TextArea.append("\n\nTrain Number" + "\t\tStaion  --->    (Arrival Time from File-1)    -    (Arrival Time from File-2)        Time Difference[HH:MM:SS]"
									/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]"
										+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]\n"*/);
								two_TextArea.append("\n\n\n\n\n\n" + file1String[0]);
								flag = false;
							}
							
							 if(spaceCount==3)
	                         {
	                         	two_TextArea.append("\n\n");
	                         	spaceCount=0;
	                         }
							if (hour > 0) {
	                           
								spaceCount++;
								two_TextArea.append("\t\t" +"                "+/* file1String[j] */station+ "      --->    "+file1String[i+1] +" - "+file2String[j+1]+"    ( " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  " );
								sign=' ';
								

							}
							if (minute >= timedifference && hour == 0) {
								
								spaceCount++;
								two_TextArea.append("\t\t" + "               "+/*file1String[j] */station+ "      --->    "+file1String[i+1] +" - "+file2String[j+1]+"   ( " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  " );
	                                 sign=' ';
							}

						}
						
						
					}
					if(Integer.valueOf(file1String[i+1])>Integer.valueOf(file2String[j+1])) {
						resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(file2String[j + 1],file1String[i + 1]);
						sign='-';
						String[] timeResult = resultString.split(":");
						int hour = 0, minute = 0, second = 0;

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);

								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						if (hour >= 0 || minute >= 0) {
							if (flag) {
								two_TextArea.append("\t\t\t\t\tTrain Time Comparison By Arrival_Time");
								two_TextArea.append("\n\nTrain Number" + "\t\tStaion  --->    (Arrival Time from File-1)    -    (Arrival Time from File-2)        Time Difference[HH:MM:SS]"
									/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]"
										+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]\n"*/);
								two_TextArea.append("\n\n\n\n\n\n" + file1String[0]);
								flag = false;
							}
							
							 if(spaceCount==3)
	                         {
	                         	two_TextArea.append("\n\n");
	                         	spaceCount=0;
	                         }
							if (hour > 0) {
	                           
								spaceCount++;
								two_TextArea.append("\t\t" +"                "+/* file1String[j] */station+ "      --->    "+file1String[i+1] +" - "+file2String[j+1]+"   (  " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  ");
								sign=' ';
								

							}
							if (minute >= timedifference && hour == 0) {
								
								spaceCount++;
								two_TextArea.append("\t\t" + "               "+/*file1String[j] */station+ "      --->    "+file1String[i+1] +" - "+file2String[j+1]+"    ( " +sign+ " [" + hour + ":"
										+ minute + ":" + second + "]   )  " );
	                                 sign=' ';
							}

						}
					}
					
					
					
					
					
					//resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(file1String[i + 2],
					//		file2String[j + 2]);
					// --------------------------------------------------->
					System.out.println("Resulst after time calculation =================>>>" + resultString);
					
					// --------------------------------------------------->
					break;
				}

			}
		}
		
		
		if(two_TextArea.getText().equals(""))
		{

			two_TextArea.append("\n\n\t\t\t\t--------------------Both File Contain Same Information--------------------  ");
		}	
		
		two_TextArea.setCaretPosition(0);
	}
	
	
	public void single_Search_ByStation()
	{
		boolean flag = true;
		String resultString = null,station=null;
		int timedifference = Integer.valueOf((String) single_TimeComboBox.getSelectedItem());
		Iterator it=two_Station_Number.iterator();
		
		String loop=null;
		single_TextArea.append("\t\t\tShowing Result For All Station From File and All Trains Halting At Cursponding Station");
		single_TextArea.append("\n\n\nStation "+"\t\t"+"Train Number ----> Arrival Time - Departure time    Halt Time[HH:MM:SS]\t\t"+"Train Number ----> Arrival Time - Departure time    Halt Time[HH:MM:SS]");
		
	while(it.hasNext()) {
		Iterator<String[]> it1 = single_ArrayListFile.iterator();
		 String stationNumber = (String)it.next();
		 System.out.println("==========================----------------------> Inside First while loop/Station Number-"+stationNumber);
		
		while (it1.hasNext()) {

			String[] strings = (String[]) it1.next();
            
			System.out.println("==========================----------------------> Inside Second while loop/Train Number-"+strings[0]);
			
			if (!(strings[0].equals(""))) {

				for (int j = 9; j < strings.length; j += 3) {
					if (strings[j].length() == 7) {
						loop= strings[j].substring(0, strings[j].length() - 4);
						System.out.println("After substring " + loop);
					}
					if (strings[j].length() == 6) {
						loop = "0"+strings[j].substring(0, strings[j].length() - 4);
						System.out.println("After substring " + loop);
					}
					if (strings[j].length() == 5) {
						loop = "00"+strings[j].substring(0, strings[j].length() - 4);
						System.out.println("After substring " + loop);
					}
					
					System.out.println("==========================---------------------->stationNumber.equals(loop)/ "+stationNumber.equals(loop));		
					if(stationNumber.equals(loop))
					  {
						System.out.println("==========================---------------------->Inside if");
						resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(strings[j + 1],
								strings[j + 2]);
						// resultString = new CompareAction().calculateTimeDifference(strings[j + 1],
						// strings[j + 2]);
						String[] timeResult = resultString.split(":");
						int hour = 0, minute = 0, second = 0;

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);

								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						//if(strings[1].toLowerCase().equals("up") || strings[1].toLowerCase().equals("down")) 
							station=stationNumber;
						if(single_fileFeedback.equals("FileFound"))
						{
							
							station=stationName.get(Integer.valueOf(stationNumber));
						}
							
						if (hour >= 0 || minute >= 0) {

							if (hour > 0) {
								
								if (flag) {
									single_TextArea.append("\n\n" + station);
								flag = false;
								}
								single_TextArea.append("\t\t     " + strings[0] + "  --->  " + strings[j + 1] + "  -  "
										+ strings[j + 2] + " [" + hour + ":" + minute + ":" + second + "]" );

								// displayResultF2.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" +
								// strings[j + 2]
								// + "\t\t" + hour + ":" + minute + ":" + second + "\n");

							}
							if (minute >= timedifference && hour == 0) {
								//
								 if (flag) {
									single_TextArea.append("\n\n" + station);
									flag = false;
								}
								single_TextArea.append("\t\t     " + strings[0] + "  --->  " + strings[j + 1] + "  -  "
										+ strings[j + 2] + " [" + hour + ":" + minute + ":" + second + "]" );

								// displayResultF2.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" +
								// strings[j + 2]
								// + "\t\t" + hour + ":" + minute + ":" + second + "\n");
							}

						}
					  
						break;
					  }
					
					

				}
				System.out.println("==========================---------------------->Outside For Loop");
				
			}
			

		}flag = true;
		System.out.println("==========================---------------------->Outside second while Loop");
		
		
	}
	System.out.println("==========================---------------------->Outside first while Loop");
	
	single_TextArea.setCaretPosition(0);	
		
	
	}
	
	
	
	public void three_Compare(int number)
	{ 
	    Map<String,String[]> three_File1=new HashMap<>();
	    Map<String,String[]> three_File2=new HashMap<>();
	   // ArrayList<String> al=new ArrayList<>();
		Iterator<String[]> it1=three_ArrayListFile1.iterator();
		Iterator<String[]> it2=three_ArrayListFile2.iterator();
		String loop=null,loop1=null,loop2=null;
		boolean flag = true;
		int spaceCount=0;
		int timedifference = Integer.valueOf((String) three_TimeComboBox.getSelectedItem());
		char sign=' ';
		 String comboSelectedStation=(String)three_StationComboBox.getSelectedItem();
		 
		 if(three_CheckBox.isSelected())
		 {
			 for (Integer o : stationName.keySet()) {
			      if (stationName.get(o).equals((String)three_StationComboBox.getSelectedItem())) {
			    	  System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Inside if  arrival.");
			    	  comboSelectedStation= o.toString();
			    	  if (comboSelectedStation.length() == 1) {
			    		  comboSelectedStation="00"+comboSelectedStation;
			    		  //	System.out.println("After substring " + loop1);
						}
			    	  if (comboSelectedStation.length() == 2) {
			    		  comboSelectedStation="0"+comboSelectedStation;
			    		  //	System.out.println("After substring " + loop1);
						}
			    	  
			    	  
			    	  System.out.println("Final Key + Length--------->"+comboSelectedStation+"  / "+comboSelectedStation.length());
				    	 
			    	  break;
			      }
		 }
		
		 }
		 
		 
		 
	System.out.println("Inside Compare 3");
		  while(it1.hasNext())
		  {
			  String[] s1=(String[])it1.next();
			  if(!(s1[0].equals("")))
			  {
				  
 				  for (int j = 9; j < s1.length; j += 3) {
						if (s1[j].length() == 7) {
							loop= s1[j].substring(0, s1[j].length() - 4);
						//	System.out.println("After substring " + loop);
						}
						if (s1[j].length() == 6) {
							loop = "0"+s1[j].substring(0, s1[j].length() - 4);
							//System.out.println("After substring " + loop);
						}
						if (s1[j].length() == 5) {
							loop = "00"+s1[j].substring(0, s1[j].length() - 4);
						//	System.out.println("After substring " + loop);
						}
						
						if(comboSelectedStation.equals(loop))
						  {
					             three_File1.put(s1[0],s1);
						  }
 				  
 				  }
 				  
				  
			  }
		  }
		  System.out.println("Trains from file -1");
		  for(Map.Entry<String, String[]> fd1:three_File1.entrySet())
		  {
			  System.out.println("Train Number===>"+fd1.getKey()+"   "+fd1.getValue());
		  }
		  
		  while(it2.hasNext())
		  {
			  String[] s1=(String[])it2.next();
			  if(!(s1[0].equals("")))
			  {
				  
 				  for (int j = 9; j < s1.length; j += 3) {
						if (s1[j].length() == 7) {
							loop= s1[j].substring(0, s1[j].length() - 4);
						//	System.out.println("After substring " + loop);
						}
						if (s1[j].length() == 6) {
							loop = "0"+s1[j].substring(0, s1[j].length() - 4);
						//	System.out.println("After substring " + loop);
						}
						if (s1[j].length() == 5) {
							loop = "00"+s1[j].substring(0, s1[j].length() - 4);
						//	System.out.println("After substring " + loop);
						}
						
						if(comboSelectedStation.equals(loop))
						  {
					             three_File2.put(s1[0],s1);
						  }
 				  
 				  }
 				  
				  
			  }
		  }
		  
		  System.out.println("Trains from file -2");
		  for(Map.Entry<String, String[]> fd1:three_File2.entrySet())
		  {
			  System.out.println("Train Number===>"+fd1.getKey()+"   "+fd1.getValue());
		  }
		  
		  
		  
		  
		 if(number==1)
		 {
			 System.out.println("Inside-1***************************************");
			 String resultString = null,station=null;
			 ArrayList<String> al=new ArrayList<String>();
			 
			
			 for(Map.Entry<String, String[]> trainNumberFromFile1:three_File1.entrySet())
			    { System.out.println("IN-FOR---1");
				  for(Map.Entry<String, String[]> trainNumberFromFile2:three_File2.entrySet())
				  {  System.out.println("IN-FOR---2");
					    System.out.println("Inside Second For Loop and befor if condition=>"+"Train Number File-1="+trainNumberFromFile1.getKey()+"Train Number File-2="+trainNumberFromFile2.getKey()+"   /"+trainNumberFromFile1.getKey().equals(trainNumberFromFile2.getKey()));
					  if((trainNumberFromFile1.getKey()).equals(trainNumberFromFile2.getKey()))
					  {  System.out.println("IN-IF---1");
						  String[] TrainDetailsFile1=trainNumberFromFile1.getValue();
						  String[] TrainDetailsFile2=trainNumberFromFile2.getValue();
						  
						  System.out.println("In File-1 -------------------------------------------->");   
						  for(int i=0;i<TrainDetailsFile1.length;i++)
						     {
						    	 System.out.println(TrainDetailsFile1[i]);
						     }
						  System.out.println("In File-2 -------------------------------------------->");   
						  for(int i=0;i<TrainDetailsFile2.length;i++)
						     {
						    	 System.out.println(TrainDetailsFile2[i]);
						     }
						     
						  
						  
						  
						  
						     
						   for(int i=9;i<TrainDetailsFile1.length;i+=3)
						      {
						    		if (TrainDetailsFile1[i].length() == 7) {
										loop1= TrainDetailsFile1[i].substring(0, TrainDetailsFile1[i].length() - 4);
									//	System.out.println("After substring " + loop1);
									}
									if (TrainDetailsFile1[i].length() == 6) {
										loop1 = "0"+TrainDetailsFile1[i].substring(0, TrainDetailsFile1[i].length() - 4);
									//	System.out.println("After substring " + loop1);
									}
									if (TrainDetailsFile1[i].length() == 5) {
										loop1 = "00"+TrainDetailsFile1[i].substring(0, TrainDetailsFile1[i].length() - 4);
									//	System.out.println("After substring " + loop1);
									}
									 System.out.println("Befor-loop-1****************************************");
						    		 
						    	  if(loop1.equals(comboSelectedStation))
						    			  {
						    		  System.out.println("Insdie-loop-1****************************************");
						    		  for(int j=9;j<TrainDetailsFile2.length;j+=3)
								      {
								    		if (TrainDetailsFile2[j].length() == 7) {
												loop2= TrainDetailsFile2[j].substring(0, TrainDetailsFile2[j].length() - 4);
										//		System.out.println("After substring " + loop2);
											}
											if (TrainDetailsFile2[j].length() == 6) {
												loop2 = "0"+TrainDetailsFile2[j].substring(0, TrainDetailsFile2[j].length() - 4);
										//		System.out.println("After substring " + loop2);
											}
											if (TrainDetailsFile2[j].length() == 5) {
												loop2 = "00"+TrainDetailsFile2[j].substring(0, TrainDetailsFile2[j].length() - 4);
										//		System.out.println("After substring " + loop2);
											}
								    	  if(loop2.equals(comboSelectedStation))
								    			  { 
								    		  System.out.println("Insdie-loop-2****************************************");
									    		         
								    		//  al.add(TrainDetailsFile2[0]);  
								    		  
								    		  if(Integer.valueOf(TrainDetailsFile1[i+1])<Integer.valueOf(TrainDetailsFile2[j+1]))
												{
													resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(TrainDetailsFile1[i + 1],
														TrainDetailsFile2[j + 1]);
													
													String[] timeResult = resultString.split(":");
													int hour = 0, minute = 0, second = 0;

													// Checking String is null or not
													if (timeResult[0].equals("0")) {
														if (timeResult[0].equals("0")) {

															hour = 0;
															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}

															}

														}

														else {
															hour = Integer.parseInt(timeResult[0]);

															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);

																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															}

														}

													} else {

														hour = Integer.parseInt(timeResult[0]);
														if (timeResult[1].equals("0")) {
															minute = 0;
															if (timeResult[2].equals("0")) {
																second = 0;
															}
														} else {
															minute = Integer.parseInt(timeResult[1]);

															if (timeResult[2].equals("0")) {
																second = 0;
															} else {
																second = Integer.parseInt(timeResult[2]);
															}
														}

													}

													station= (String)three_StationComboBox.getSelectedItem();
													if(three_fileFeedback.equals("FileFound"))
													{
														
														station=stationName.get(Integer.valueOf(comboSelectedStation));
													}
													
													if (hour >= 0 || minute >= 0) {
														if (flag) {
															three_TextArea.append("\t\t\t\t\tStation Comparison By Arrival_Time");
															three_TextArea.append("\n\nStation " + "\t\tTrain Number --->    (Arrival Time from File-1)    -    (Arrival Time from File-2)        Time Difference[HH:MM:SS]"
																/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]"
																	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]\n"*/);
															three_TextArea.append("\n\n\n\n\n\n" + station);
															flag = false;
														}
														
														 if(spaceCount==3)
								                         {
								                         	three_TextArea.append("\n\n");
								                         	spaceCount=0;
								                         }
														if (hour > 0) {
								                           
															spaceCount++;
															three_TextArea.append("\t\t" +"                "+/* file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i + 1] +" - "+TrainDetailsFile2[j+1]+"    ( " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  " );
															sign=' ';
															

														}
														if (minute >= timedifference && hour == 0) {
															
															spaceCount++;
															three_TextArea.append("\t\t" + "               "+/*file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i+1] +" - "+TrainDetailsFile2[j+1]+"   ( " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  " );
								                                 sign=' ';
														}

													}
													
													
												}
								    		  
								    		  if(Integer.valueOf(TrainDetailsFile1[i+1])>Integer.valueOf(TrainDetailsFile2[j+1])) {
													resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(TrainDetailsFile2[j + 1],TrainDetailsFile1[i + 1]);
													sign='-';
													String[] timeResult = resultString.split(":");
													int hour = 0, minute = 0, second = 0;

													// Checking String is null or not
													if (timeResult[0].equals("0")) {
														if (timeResult[0].equals("0")) {

															hour = 0;
															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}

															}

														}

														else {
															hour = Integer.parseInt(timeResult[0]);

															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);

																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															}

														}

													} else {

														hour = Integer.parseInt(timeResult[0]);
														if (timeResult[1].equals("0")) {
															minute = 0;
															if (timeResult[2].equals("0")) {
																second = 0;
															}
														} else {
															minute = Integer.parseInt(timeResult[1]);

															if (timeResult[2].equals("0")) {
																second = 0;
															} else {
																second = Integer.parseInt(timeResult[2]);
															}
														}

													}

													station= (String)three_StationComboBox.getSelectedItem();
															if(three_fileFeedback.equals("FileFound"))
															{
																
																station=stationName.get(Integer.valueOf(comboSelectedStation));
															}
													if (hour >= 0 || minute >= 0) {
														if (flag) {
															three_TextArea.append("\t\t\t\t\tStation Comparison By Arrival_Time");
															three_TextArea.append("\n\nStation" + "\t\tTrain Number --->    (Arrival Time from File-1)    -    (Arrival Time from File-2)        Time Difference[HH:MM:SS]"
																/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]"
																	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]\n"*/);
															three_TextArea.append("\n\n\n\n\n\n" + station);
															flag = false;
														}
														
														 if(spaceCount==3)
								                         {
								                         	three_TextArea.append("\n\n");
								                         	spaceCount=0;
								                         }
														if (hour > 0) {
								                           
															spaceCount++;
															three_TextArea.append("\t\t" +"                "+/* file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i+1] +" - "+TrainDetailsFile2[j+1]+"   (  " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  ");
															sign=' ';
															

														}
														if (minute >= timedifference && hour == 0) {
															
															spaceCount++;
															three_TextArea.append("\t\t" + "               "+/*file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i+1] +" - "+TrainDetailsFile2[j+1]+"    ( " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  " );
								                                 sign=' ';
														}

													}
												}
								    		  
								    	
								    		  
								    		  
								    		  break;
								    			  }
								      }    
						    			  }
						      }
						 
						  
					break;
					}
					  
				  }
			  }
			 
			   
			 
				
                 //System.out.println("Array List ===>"+al);
			  
		 }
		 if(number==2)
		 {

			
			 
			 String resultString = null,station=null;
			 for(Map.Entry<String, String[]> trainNumberFromFile1:three_File1.entrySet())
			    {
				  for(Map.Entry<String, String[]> trainNumberFromFile2:three_File2.entrySet())
				  { 
					    System.out.println("Inside Second For Loop and befor if condition=>"+"Train Number File-1="+trainNumberFromFile1.getKey()+"Train Number File-2="+trainNumberFromFile2.getKey()+"   /"+trainNumberFromFile1.getKey().equals(trainNumberFromFile2.getKey()));
					  if((trainNumberFromFile1.getKey()).equals(trainNumberFromFile2.getKey()))
					  {
						  String[] TrainDetailsFile1=trainNumberFromFile1.getValue();
						  String[] TrainDetailsFile2=trainNumberFromFile2.getValue();
						  
						  System.out.println("In File-1 -------------------------------------------->");   
						  for(int i=0;i<TrainDetailsFile1.length;i++)
						     {
						    	 System.out.println(TrainDetailsFile1[i]);
						     }
						  System.out.println("In File-2 -------------------------------------------->");   
						  for(int i=0;i<TrainDetailsFile2.length;i++)
						     {
						    	 System.out.println(TrainDetailsFile2[i]);
						     }
						     
						  
						  
						  
						  
						     
						   for(int i=9;i<TrainDetailsFile1.length;i+=3)
						      {
						    		if (TrainDetailsFile1[i].length() == 7) {
										loop1= TrainDetailsFile1[i].substring(0, TrainDetailsFile1[i].length() - 4);
										System.out.println("After substring " + loop1);
									}
									if (TrainDetailsFile1[i].length() == 6) {
										loop1 = "0"+TrainDetailsFile1[i].substring(0, TrainDetailsFile1[i].length() - 4);
										System.out.println("After substring " + loop1);
									}
									if (TrainDetailsFile1[i].length() == 5) {
										loop1 = "00"+TrainDetailsFile1[i].substring(0, TrainDetailsFile1[i].length() - 4);
										System.out.println("After substring " + loop1);
									}
						    	  if(loop1.equals(comboSelectedStation))
						    			  {
						    		  for(int j=9;j<TrainDetailsFile2.length;j+=3)
								      {
								    		if (TrainDetailsFile2[j].length() == 7) {
												loop2= TrainDetailsFile2[j].substring(0, TrainDetailsFile2[j].length() - 4);
												System.out.println("After substring " + loop2);
											}
											if (TrainDetailsFile2[j].length() == 6) {
												loop2 = "0"+TrainDetailsFile2[j].substring(0, TrainDetailsFile2[j].length() - 4);
												System.out.println("After substring " + loop2);
											}
											if (TrainDetailsFile2[j].length() == 5) {
												loop2 = "00"+TrainDetailsFile2[j].substring(0, TrainDetailsFile2[j].length() - 4);
												System.out.println("After substring " + loop2);
											}
								    	  if(loop2.equals(comboSelectedStation))
								    			  {
								    		                 
								    		  
								    		  if(Integer.valueOf(TrainDetailsFile1[i+2])<Integer.valueOf(TrainDetailsFile2[j+2]))
												{
													resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(TrainDetailsFile1[i + 2],
														TrainDetailsFile2[j + 2]);

                                                    System.out.println("------------------------------->>>>>>>>>>>>>Time "+ resultString);
													String[] timeResult = resultString.split(":");
													int hour = 0, minute = 0, second = 0;

													// Checking String is null or not
													if (timeResult[0].equals("0")) {
														if (timeResult[0].equals("0")) {

															hour = 0;
															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}

															}

														}

														else {
															hour = Integer.parseInt(timeResult[0]);

															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);

																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															}

														}

													} else {

														hour = Integer.parseInt(timeResult[0]);
														if (timeResult[1].equals("0")) {
															minute = 0;
															if (timeResult[2].equals("0")) {
																second = 0;
															}
														} else {
															minute = Integer.parseInt(timeResult[1]);

															if (timeResult[2].equals("0")) {
																second = 0;
															} else {
																second = Integer.parseInt(timeResult[2]);
															}
														}

													}

													station= (String)three_StationComboBox.getSelectedItem();
													if(three_fileFeedback.equals("FileFound"))
													{
														
														station=stationName.get(Integer.valueOf(comboSelectedStation));
													}
													if (hour >= 0 || minute >= 0) {
														if (flag) {
															three_TextArea.append("\t\t\t\t\tStation Comparison By Departure_Time");
															three_TextArea.append("\n\nStation " + "\t\tTrain Number --->    (Departure Time from File-1)    -    (Departure Time from File-2)        Time Difference[HH:MM:SS]"
																/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]"
																	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2   Time Difference[HH:MM:SS]\n"*/);
															three_TextArea.append("\n\n\n\n\n\n" + station);
															flag = false;
														}
														
														 if(spaceCount==3)
								                         {
								                         	three_TextArea.append("\n\n");
								                         	spaceCount=0;
								                         }
														if (hour > 0) {
								                           
															spaceCount++;
															three_TextArea.append("\t\t" +"                "+/* file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i + 2] +" - "+TrainDetailsFile2[j+2]+"    ( " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  " );
															sign=' ';
															

														}
														if (minute >= timedifference && hour == 0) {
															
															spaceCount++;
															three_TextArea.append("\t\t" + "               "+/*file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i+2] +" - "+TrainDetailsFile2[j+2]+"   ( " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  " );
								                                 sign=' ';
														}

													}
													
													
												}
								    		  
								    		  if(Integer.valueOf(TrainDetailsFile1[i+2])>Integer.valueOf(TrainDetailsFile2[j+2])) {
													resultString = TimeDifferenceCalculation.getTD().time_Difference_Calculation(TrainDetailsFile2[j + 2],TrainDetailsFile1[i + 2]);
													sign='-';
													String[] timeResult = resultString.split(":");
													int hour = 0, minute = 0, second = 0;
                                                     System.out.println("------------------------------->>>>>>>>>>>>>Time "+ resultString);
													// Checking String is null or not
													if (timeResult[0].equals("0")) {
														if (timeResult[0].equals("0")) {

															hour = 0;
															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);
																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}

															}

														}

														else {
															hour = Integer.parseInt(timeResult[0]);

															if (timeResult[1].equals("0")) {
																minute = 0;
																if (timeResult[2].equals("0")) {
																	second = 0;
																}
															} else {
																minute = Integer.parseInt(timeResult[1]);

																if (timeResult[2].equals("0")) {
																	second = 0;
																} else {
																	second = Integer.parseInt(timeResult[2]);
																}
															}

														}

													} else {

														hour = Integer.parseInt(timeResult[0]);
														if (timeResult[1].equals("0")) {
															minute = 0;
															if (timeResult[2].equals("0")) {
																second = 0;
															}
														} else {
															minute = Integer.parseInt(timeResult[1]);

															if (timeResult[2].equals("0")) {
																second = 0;
															} else {
																second = Integer.parseInt(timeResult[2]);
															}
														}

													}
													station= (String)three_StationComboBox.getSelectedItem();
													if(three_fileFeedback.equals("FileFound"))
													{
														
														station=stationName.get(Integer.valueOf(comboSelectedStation));
													}

													if (hour >= 0 || minute >= 0) {
														if (flag) {
															three_TextArea.append("\t\t\t\t\tStation Comparison By Departure_Time");
															three_TextArea.append("\n\nStation" + "\t\tTrain Number --->    (Departure Time from File-1)    -    (Departure Time from File-2)        Time Difference[HH:MM:SS]"
																/*	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]"
																	+ "\t\tStaion Number --->Departure Time from File-1 - Departure Time from File-2  Time Difference[HH:MM:SS]\n"*/);
															three_TextArea.append("\n\n\n\n\n\n" + comboSelectedStation);
															flag = false;
														}
														
														 if(spaceCount==3)
								                         {
								                         	three_TextArea.append("\n\n");
								                         	spaceCount=0;
								                         }
														if (hour > 0) {
								                           
															spaceCount++;
															three_TextArea.append("\t\t" +"                "+/* file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i+2] +" - "+TrainDetailsFile2[j+2]+"   (  " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  ");
															sign=' ';
															

														}
														if (minute >= timedifference && hour == 0) {
															
															spaceCount++;
															three_TextArea.append("\t\t" + "               "+/*file1String[j] */trainNumberFromFile1.getKey()+ "      --->    "+TrainDetailsFile1[i+2] +" - "+TrainDetailsFile2[j+2]+"    ( " +sign+ " [" + hour + ":"
																	+ minute + ":" + second + "]   )  " );
								                                 sign=' ';
														}

													}
												}
								    		  
								    		  
								    		  break;
								    			  }
								      }    
						    			  }
						      }
						  
					break;
					}
					  
				  }
			  }
			  
			
		 }
		  
		  System.out.println(""+three_File1.isEmpty()+three_File1.size());
		  System.out.println(""+three_File2.isEmpty()+three_File2.size());
		  System.out.println("+++++++++++++++++++++++++++++++++++++++++ Befor ending");
		  if(three_TextArea.getText().equals(""))
			{
			three_TextArea.append("\n\n\t\t\t\t ---------------------Both File Contain Same Information--------------------");
			
			} 
		  
		  
		  
		  
		  System.out.println("****************************Text "+three_TextArea.getText());
		  three_TextArea.setCaretPosition(0); 
		
		  System.out.println("+++++++++++++++++++++++++++++++++++++++++ After ending");
		  
	
		
	}
	
	
	
	
	

}
