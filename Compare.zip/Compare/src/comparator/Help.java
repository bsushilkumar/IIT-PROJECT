package comparator;

import static comparator.Comparator.help_TextArea;
public class Help {
	
	public Help() {
		 displayText();
	}
	
	
	void displayText() {
		help_TextArea.setFont(help_TextArea.getFont().deriveFont(14f));
		
		help_TextArea.append("\n\n   Note :  ' - ' sign before any Time indicate Earlier time.  "
				+ "\n\n\t 1. Single File Statistics Tab : "
				+ "\n\n\t   => Display All Trains and It's Cursponding Halting Stations From File."
				+ "\n\t   => Display All Station From File and All Trains Halt At Cursponding Station."
				+ "\n\n\t 2. Two File Comparison By Train Tab"
				+ "\n\t    => Comparing Selected Train Based on Arrival or Departure Time From Two Files.  "
				+ "\n\n\t 3. Two File Comparison By Station"
				+ "\n\t   =>Comparison By Station. After Selecting Station From List. It Will Show All Trains From Both File.");
		
	}

}
