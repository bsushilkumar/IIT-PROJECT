package comparator;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JFileChooser;
import static comparator.Comparator.*;
public class StationName {
	
	
	public static Map<Integer, String> stationName=null;
	
	public String findStationFile(String path,int number)
	{  
		stationName=new HashMap<Integer,String>();
		String absolutePath=path+"\\station.txt";
		
		ArrayList fileDetails = new ArrayList<String[]>();
			 stationName=new HashMap<Integer,String>();
            String lineFile1="";
            String csvSplitBy = "\\s+";
            
			System.out.println("single_ArrayListFile Creation" + fileDetails.size());
			BufferedReader file1Buffer=null;
			try {
				file1Buffer = new BufferedReader(new FileReader(absolutePath));
				while ((lineFile1 = file1Buffer.readLine()) != null) {
					// use space as separator  
					String[] lineRecord = lineFile1.split(csvSplitBy);
					fileDetails.add(lineRecord);
				}
			} catch (FileNotFoundException e) {
				if(number==1) {
				single_CheckBox.setForeground(Color.RED);
				single_CheckBox.setText("File Not Found");
				e.printStackTrace();
				}
				
				if(number==2) {
					two_CheckBox.setForeground(Color.RED);
					two_CheckBox.setText("File Not Found");
					e.printStackTrace();
					}
				if(number==3) {
					three_CheckBox.setForeground(Color.RED);
					three_CheckBox.setText("File Not Found");
					e.printStackTrace();
					}
				
				return "FileNotFound";
			}
			catch(IOException e)
			{
			    e.printStackTrace();  	
			}finally {
				if (file1Buffer != null) {
					try {
						file1Buffer.close();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
			}
			
			if(number==1) {
			single_CheckBox.setForeground(Color.BLUE);
			single_CheckBox.setText("File Found");
			}
			
			if(number==2) {
				two_CheckBox.setForeground(Color.BLUE);
				two_CheckBox.setText("File Found");
				}
			
			if(number==3) {
				three_CheckBox.setForeground(Color.BLUE);
				three_CheckBox.setText("File Found");
				}
		fileDetails.remove(0);
		
		System.out.println("Array List size===="+fileDetails.size());
			Iterator it=fileDetails.iterator();
			int cout=0;
	while(it.hasNext())
				
			{
				
				String[] s=(String[])it.next();
				
				if(!(s[0].equals("")))
				{ 
					
					cout++;
					//System.out.println(cout);
				System.out.println("Station name-"+s[0]);
				
				stationName.put(cout, s[0]);
				
			/*	 for(int i=0;i<s.length;i++)
				 {  
					 //System.out.println("Count-"+cout);
					 System.out.print(" "+s[i]);
					 
				 }  */
				 System.out.println();
			}}
			
	
	String[] stationNames=new String[stationName.size()];
			for(int i=0;i<stationName.size();i++)
			{
				stationNames[i]=stationName.get(i+1);
			}
			
			System.out.println("Length of Map-"+stationName.size());
			System.out.println(stationName.get(5));
			System.out.println("String Lenght- "+stationNames.length);
			System.out.println("Strings from station names");
			for(int i=0;i<stationNames.length;i++)
			{
				System.out.println(stationNames[i]);
			}
		

		return "FileFound";
		

}
}
