package comparator;

import static comparator.Comparator.*;
import static comparator.StationName.stationName;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import javax.swing.DefaultComboBoxModel;

/*
 * @This class sorting Train List and Loop Number as per ascending order 
 */
public class TrainAndLoopNumberSorting {
	public static TreeSet two_TrainList_File2,two_Station_Number,three_StationFile1,three_StationFile2;
	
	public void single_Train_And_Loop_Number_Sorting()
	{
		
		trainNumber=new TreeSet();
		loopNumber=new TreeSet();
		Iterator<String[]> it = single_ArrayListFile.iterator();
		System.out.println("Array List Size Which hast data"+single_ArrayListFile.size());
		while (it.hasNext()) {
			 System.out.println("Inside While loop");
			String[] strings = (String[]) it.next();
			String str=null;


			if(!(strings[0].equals(""))) {
			trainNumber.add(strings[0]);
			
				
				for (int j = 9; j < strings.length; j += 3) {

					if(strings[j].length()==7)
					{
						loopNumber.add(strings[j].substring(0, strings[j].length()-4));
					}
					if(strings[j].length()==6) {
						str="0"+strings[j].substring(0, strings[j].length()-4);
						loopNumber.add(str);
					}
					if(strings[j].length()==5) {
						str="00"+strings[j].substring(0, strings[j].length()-4);
						loopNumber.add(str);
							
					}
					
					}	
		}
			}

		System.out.println("Train Numbers in Sorting Order-->"+trainNumber);
		System.out.println("Loop Number-->"+loopNumber);
		two_Station_Number=loopNumber;
		Comparator.single_TextArea.append("\t\t\t\t\t\tFile Statistics");
		Comparator.single_TextArea.append("\n\n\nTotal Number of Trains in File ");
		Comparator.single_TextArea.append(" (");
		Comparator.single_TextArea.append("Train Count --> "+trainNumber.size());
		Comparator.single_TextArea.append(") ");
		Comparator.single_TextArea.append("\nTrain List--> "+trainNumber);
		Comparator.single_TextArea.append("\n\nTotal Number of Stations");
		Comparator.single_TextArea.append(" (");
		Comparator.single_TextArea.append("Station Count--> "+loopNumber.size());
		Comparator.single_TextArea.append(") ");
		Comparator.single_TextArea.append("\nStation List--> "+loopNumber);
		}
	
	public void two_Train_And_Loop_Number_Sorting(int number)
         {
		     System.out.println("In TrainSorting ArraySize file-1--->"+two_ArrayListFile1.size());
		     if(number==1) 
		     {
		    	 trainNumber=new TreeSet();
		 		loopNumber=new TreeSet();
		 	    String str=null;
		 		Iterator<String[]> it = two_ArrayListFile1.iterator();
		 		//System.out.println("Array List Size Which hast data"+two_ArrayListFile1.size());
		 		while (it.hasNext()) {
		 		//	 System.out.println("Inside While loop");
		 			String[] strings = (String[]) it.next();
		 			for(int i=0; i<strings.length;i++)
		 			{ // System.out.println("For Loop First Line  ---------------> "+strings[i]);
		 				} 
		 			
		 			if(!(strings[0].equals(""))) {
		 				trainNumber.add(strings[0]);
		 				
		 					
		 					for (int j = 9; j < strings.length; j += 3) {

		 						if(strings[j].length()==7)
		 						{
		 							loopNumber.add(strings[j].substring(0, strings[j].length()-4));
		 						}
		 						if(strings[j].length()==6) {
		 							str="0"+strings[j].substring(0, strings[j].length()-4);
		 							loopNumber.add(str);
		 						}
		 						if(strings[j].length()==5) {
		 							str="00"+strings[j].substring(0, strings[j].length()-4);
		 							loopNumber.add(str);
		 								
		 						}
		 						
		 						}		
		 					
		 			}
		 	
		 		
		     }
		 		//System.out.println("Train Numbers----->"+trainNumber);
		 		String[] trainListF1 = (String[]) trainNumber.toArray(new String[trainNumber.size()]);
		 		
				two_TrainList.setModel(new DefaultComboBoxModel(trainListF1));
				two_TrainList.setEnabled(true);
				two_TrainList.setEditable(false);
				two_TrainList.setSelectedIndex(0);
				two_TrainList.setEnabled(true);
            
				Comparator.two_TextArea.append("\t\t\t\t\t\tFile-1 Statistics");
				Comparator.two_TextArea.append("\n\n\nTotal Number of Trains in File-1 ");
				Comparator.two_TextArea.append(" (");
				Comparator.two_TextArea.append("Train Count --> "+trainNumber.size());
				Comparator.two_TextArea.append(") ");
				Comparator.two_TextArea.append("\nTrain List--> "+trainNumber);
				Comparator.two_TextArea.append("\n\nTotal Number of Stations");
				Comparator.two_TextArea.append(" (");
				Comparator.two_TextArea.append("Station Count--> "+loopNumber.size());
				Comparator.two_TextArea.append(") ");
				Comparator.two_TextArea.append("\nStation List--> "+loopNumber);
				Comparator.two_TextArea.append("\n\n\n\n\n\n");
		 		
		 /*		Comparator.two_TextArea.append("\t\t\t\t\t\t\tFile-1 Statistics");
		 		Comparator.single_TextArea.append("\n\nTotal Number of Trains in File-1 ");
				Comparator.two_TextArea.append("\tTrain Count --> "+trainNumber.size());
				Comparator.two_TextArea.append("\nTrain List--> "+trainNumber);
				Comparator.two_TextArea.append("\n\nStation Count--> "+loopNumber.size());
				Comparator.two_TextArea.append("\nStation List--> "+loopNumber);
				
		     */
		     }
		     if(number==2)
		     {
		    	 System.out.println("In TrainSorting ArraySize file-2--->"+two_ArrayListFile2.size());
		    	 trainNumber=new TreeSet();
			 		loopNumber=new TreeSet();
			 		String str=null;
			 		Iterator<String[]> it = two_ArrayListFile2.iterator();
			 	//	System.out.println("Array List Size Which hast data"+two_ArrayListFile2.size());
			 		while (it.hasNext()) {
			 		//	 System.out.println("Inside While loop");
			 			String[] strings = (String[]) it.next();
			 			if(!(strings[0].equals(""))) {
			 				trainNumber.add(strings[0]);
			 				
			 					
			 					for (int j = 9; j < strings.length; j += 3) {

			 						if(strings[j].length()==7)
			 						{
			 							
			 							loopNumber.add(strings[j].substring(0, strings[j].length()-4));
			 						}
			 						if(strings[j].length()==6) {
			 						     str="0"+strings[j].substring(0, strings[j].length()-4);
			 							loopNumber.add(str);
			 						}
			 						if(strings[j].length()==5) {
			 							str="00"+strings[j].substring(0, strings[j].length()-4);
			 							loopNumber.add(str);
			 								
			 						}
			 						
			 						}		
			 			}
			 		
			 	
			    
		     }
			 		two_TrainList_File2=trainNumber;
			 		Comparator.two_TextArea.append("\t\t\t\t\t\tFile-2 Statistics");
					Comparator.two_TextArea.append("\n\n\nTotal Number of Trains in File-2 ");
					Comparator.two_TextArea.append(" (");
					Comparator.two_TextArea.append("Train Count --> "+trainNumber.size());
					Comparator.two_TextArea.append(") ");
					Comparator.two_TextArea.append("\nTrain List--> "+trainNumber);
					Comparator.two_TextArea.append("\n\nTotal Number of Stations");
					Comparator.two_TextArea.append(" (");
					Comparator.two_TextArea.append("Station Count--> "+loopNumber.size());
					Comparator.two_TextArea.append(") ");
					Comparator.two_TextArea.append("\nStation List--> "+loopNumber);
					Comparator.two_TextArea.append("\n\n");
			 		
			 		
			 		/*
			 		Comparator.two_TextArea.append("\t\t\t\t\t\t\tFile-2 Statistics");
			 		Comparator.single_TextArea.append("\n\nTotal Number of Trains in File-2 ");
					Comparator.two_TextArea.append("\tTrain Count --> "+trainNumber.size());
					Comparator.two_TextArea.append("\n Train List--> "+trainNumber);
					Comparator.two_TextArea.append("\n\nStation Count--> "+loopNumber.size());
					Comparator.two_TextArea.append("\nStation List--> "+loopNumber);
		     */
		}
	}
	
	
	
	public void three_Train_And_Loop_Number_Sorting(int number)
	{
		  if(number==1) 
		     {
		    	 trainNumber=new TreeSet();
		 		loopNumber=new TreeSet();
		 	    String str=null;
		 		Iterator<String[]> it = three_ArrayListFile1.iterator();
		 		//System.out.println("Array List Size Which hast data"+two_ArrayListFile1.size());
		 		while (it.hasNext()) {
		 		//	 System.out.println("Inside While loop");
		 			String[] strings = (String[]) it.next();
		 			for(int i=0; i<strings.length;i++)
		 			{ // System.out.println("For Loop First Line  ---------------> "+strings[i]);
		 				} 
		 			
		 			if(!(strings[0].equals(""))) {
		 				trainNumber.add(strings[0]);
		 				
		 					
		 					for (int j = 9; j < strings.length; j += 3) {

		 						if(strings[j].length()==7)
		 						{
		 							loopNumber.add(strings[j].substring(0, strings[j].length()-4));
		 						}
		 						if(strings[j].length()==6) {
		 							str="0"+strings[j].substring(0, strings[j].length()-4);
		 							loopNumber.add(str);
		 						}
		 						if(strings[j].length()==5) {
		 							str="00"+strings[j].substring(0, strings[j].length()-4);
		 							loopNumber.add(str);
		 								
		 						}
		 						
		 						}		
		 					
		 			}
		 	
		 		
		     }
		 		//System.out.println("Train Numbers----->"+trainNumber);
		 		three_StationFile1=loopNumber;
		 	
         
				Comparator.three_TextArea.append("\t\t\t\t\t\tFile-1 Statistics");
				Comparator.three_TextArea.append("\n\n\nTotal Number of Trains in File-1 ");
				Comparator.three_TextArea.append(" (");
				Comparator.three_TextArea.append("Train Count --> "+trainNumber.size());
				Comparator.three_TextArea.append(") ");
				Comparator.three_TextArea.append("\nTrain List--> "+trainNumber);
				Comparator.three_TextArea.append("\n\nTotal Number of Stations");
				Comparator.three_TextArea.append(" (");
				Comparator.three_TextArea.append("Station Count--> "+loopNumber.size());
				Comparator.three_TextArea.append(") ");
				Comparator.three_TextArea.append("\nStation List--> "+loopNumber);
				Comparator.three_TextArea.append("\n\n\n\n\n");
		 		
		 /*		Comparator.two_TextArea.append("\t\t\t\t\t\t\tFile-1 Statistics");
		 		Comparator.single_TextArea.append("\n\nTotal Number of Trains in File-1 ");
				Comparator.two_TextArea.append("\tTrain Count --> "+trainNumber.size());
				Comparator.two_TextArea.append("\nTrain List--> "+trainNumber);
				Comparator.two_TextArea.append("\n\nStation Count--> "+loopNumber.size());
				Comparator.two_TextArea.append("\nStation List--> "+loopNumber);
				
		     */
		     }
		  
		     if(number==2)
		     {
		    	 TreeSet commonStationList;
		    	 System.out.println("In TrainSorting ArraySize file-2--->"+three_ArrayListFile2.size());
		    	 trainNumber=new TreeSet();
			 		loopNumber=new TreeSet();
			 		String str=null;
			 		Iterator<String[]> it = three_ArrayListFile2.iterator();
			 	//	System.out.println("Array List Size Which hast data"+two_ArrayListFile2.size());
			 		while (it.hasNext()) {
			 		//	 System.out.println("Inside While loop");
			 			String[] strings = (String[]) it.next();
			 			if(!(strings[0].equals(""))) {
			 				trainNumber.add(strings[0]);
			 				
			 					
			 					for (int j = 9; j < strings.length; j += 3) {

			 						if(strings[j].length()==7)
			 						{
			 							
			 							loopNumber.add(strings[j].substring(0, strings[j].length()-4));
			 						}
			 						if(strings[j].length()==6) {
			 						     str="0"+strings[j].substring(0, strings[j].length()-4);
			 							loopNumber.add(str);
			 						}
			 						if(strings[j].length()==5) {
			 							str="00"+strings[j].substring(0, strings[j].length()-4);
			 							loopNumber.add(str);
			 								
			 						}
			 						
			 						}		
			 			}
			 		
			 	
			    
		     }
			 		three_StationFile2=loopNumber;
			 		String[] stationListF1;
			 		commonStationList=new TreeSet<>(three_StationFile1);
			 		commonStationList.retainAll(three_StationFile2);
			 		System.out.println("Common List---------------------"+commonStationList);
			 		
			 		 stationListF1 = (String[]) commonStationList.toArray(new String[commonStationList.size()]);
			 		if(three_CheckBox.isSelected())
			 		{    String[] station_Name=new String[commonStationList.size()];
			 		     int count=0;
			 			Iterator it1=commonStationList.iterator();
			 			while (it1.hasNext()) {
							station_Name[count]=stationName.get(Integer.valueOf((String) it1.next()));
							count++;
							
						}
			 			
			 			stationListF1=station_Name;
			 		}
			 		
			 		System.out.println("#########################################----------------------->>>>>>>>Station List");
			 		for (int i = 0; i < stationListF1.length; i++) {
						System.out.println(stationListF1[i]);
					}
					three_StationComboBox.setModel(new DefaultComboBoxModel(stationListF1));
					three_StationComboBox.setEnabled(true);
					three_StationComboBox.setEditable(false);
					three_StationComboBox.setSelectedIndex(0);
					three_StationComboBox.setEnabled(true);
			 		
			 		Comparator.three_TextArea.append("\t\t\t\t\t\tFile-2 Statistics");
					Comparator.three_TextArea.append("\n\n\nTotal Number of Trains in File-2 ");
					Comparator.three_TextArea.append(" (");
					Comparator.three_TextArea.append("Train Count --> "+trainNumber.size());
					Comparator.three_TextArea.append(") ");
					Comparator.three_TextArea.append("\nTrain List--> "+trainNumber);
					Comparator.three_TextArea.append("\n\nTotal Number of Stations");
					Comparator.three_TextArea.append(" (");
					Comparator.three_TextArea.append("Station Count--> "+loopNumber.size());
					Comparator.three_TextArea.append(") ");
					Comparator.three_TextArea.append("\nStation List--> "+loopNumber);
					Comparator.three_TextArea.append("\n\n");
			 		
			 		
			 		/*
			 		Comparator.two_TextArea.append("\t\t\t\t\t\t\tFile-2 Statistics");
			 		Comparator.single_TextArea.append("\n\nTotal Number of Trains in File-2 ");
					Comparator.two_TextArea.append("\tTrain Count --> "+trainNumber.size());
					Comparator.two_TextArea.append("\n Train List--> "+trainNumber);
					Comparator.two_TextArea.append("\n\nStation Count--> "+loopNumber.size());
					Comparator.two_TextArea.append("\nStation List--> "+loopNumber);
		     */
		}
		  
		  
		  
	}
	
	
}
	


