package compare;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class CompareTrainsByTime {
    
     
	private JButton file1, file2;
	private JLabel pathFile1, pathFile2;
	private JComboBox trainList, timeList;
	private String[] time = { " ", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55" };
	private JButton searchDifference;
	private JLabel lblTrain, lblTime;
	private ArrayList<String[]> alFile1;
	private ArrayList<String[]> alFile2;
	private ArrayList<String> trainListFile1;
	private JTextArea displayResultF1, displayResultF2;
	private BufferedReader brFile1 = null;
	private String lineFile1 = "", resultString = "";
	private BufferedReader brFile2 = null;
	private String lineFile2 = "";
	private String csvSplitBy = "\\s+";
	private JFrame frameObj;
	private boolean flag = true;

	public CompareTrainsByTime() {
		//Frame Creation
		frameObj = new JFrame("Compare");
		frameObj.setLayout(null);
		frameObj.setVisible(true);
		frameObj.setSize(1363, 732);
		
        //File Buttons
		file1 = new JButton("File-1");
		pathFile1 = new JLabel("Select File-1");
		pathFile2 = new JLabel("Select File-2");
		file2 = new JButton("File-2");
		
		//Train List and Time List 
		trainList = new JComboBox();
		trainList.setEnabled(false);
		timeList = new JComboBox(time);
		
		// Code to set Item in Middle in JComboBox
		DefaultListCellRenderer dlcr = new DefaultListCellRenderer();
		dlcr.setHorizontalAlignment(DefaultListCellRenderer.CENTER);
		timeList.setRenderer(dlcr);
		trainList.setRenderer(dlcr);
		timeList.setEnabled(false);
		
		//Search Button 
		searchDifference = new JButton("Search");
		
		//Label
		lblTrain = new JLabel("Train Number");
		lblTime = new JLabel("Time Difference (In Minutes)");
		
		//TextArea to display Result of train
		displayResultF1 = new JTextArea();
		displayResultF1.setEditable(false);

		JScrollPane scrolltxt1 = new JScrollPane(displayResultF1);
		displayResultF2 = new JTextArea();
		displayResultF2.setEditable(false);
		JScrollPane scrolltxt2 = new JScrollPane(displayResultF2);

		//Adding component to Frame
		frameObj.add(file1);
		frameObj.add(pathFile1);
		frameObj.add(file2);
		frameObj.add(pathFile2);
		frameObj.add(trainList);
		frameObj.add(lblTrain);
		frameObj.add(lblTime);
		frameObj.add(timeList);
		frameObj.add(searchDifference);
		frameObj.add(scrolltxt1);
		frameObj.add(scrolltxt2);

		// Set Component location and size
		file2.setBounds(700, 30, 100, 40);
		file1.setBounds(30, 30, 100, 40);
		pathFile1.setBounds(150, 30, 500, 40);
		pathFile2.setBounds(820, 30, 500, 40);
		lblTrain.setBounds(30, 150, 80, 40);
		trainList.setBounds(120, 153, 180, 30);
		lblTime.setBounds(350, 150, 160, 40);
		timeList.setBounds(520, 153, 180, 30);
		searchDifference.setBounds(725, 150, 100, 40);

		scrolltxt1.setBounds(30, 260, 630, 400);
		scrolltxt2.setBounds(700, 260, 630, 400);

		
  /*
   * @ Adding ActionListener to trainList ComboBox.
   */
		trainList.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				displayResultF1.setText("");
				displayResultF2.setText("");

			}
		});

		
  /*
   * @ Adding ActionListener to timeList ComboBox.
   */		
		timeList.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				displayResultF1.setText("");
				displayResultF2.setText("");

			}
		});
		
		
  /*
   * @ Adding ActionListener to file1 button.
   * @After click on this button it starts reading train loopNumber from .csv file and store it into "alFile1" ArrayList
   * @After that TrainList() method get call which is present in "CompareAction" class. CompareAction is Inner class.
   */	
		file1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				File selectedFile;
				JFileChooser fileChooser = new JFileChooser();
				int result = fileChooser.showOpenDialog(frameObj);
				if (result == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
			/*		String name=selectedFile.getName();
					System.out.println((name.substring(name.lastIndexOf(".")+1)));
					if((name.substring(name.lastIndexOf(".")+1)).equals("csv"))
					{
			*/		
					pathFile1.setText(selectedFile.getAbsolutePath());
					try {
						alFile1 = new ArrayList<String[]>();
						brFile1 = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
						while ((lineFile1 = brFile1.readLine()) != null) {
							// use space as separator
							String[] lineRecord = lineFile1.split(csvSplitBy);
							alFile1.add(lineRecord);
						}
/*
 * @calling TrainList() method of CompareAction Class which is inner class
 */
						new CompareAction().TrainList();

					} catch (FileNotFoundException ex) {
						ex.printStackTrace();
					} catch (IOException ex) {
						ex.printStackTrace();
					} finally {
						if (brFile1 != null) {
							try {
								brFile1.close();
							} catch (IOException ex) {
								ex.printStackTrace();
							}
						}
					}
		/*		}else {
					JOptionPane.showMessageDialog(frameObj, "Selecte .csv file only");
					
				}
				*/
				}
			}
		});

		

  /*
   * @ Adding ActionListener to file2 button.
   * @After click on this button it starts reading .csv file and store it into "alFile2" ArrayList for comparison.
   */	

		file2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();

				int result = fileChooser.showOpenDialog(frameObj);
				if (result == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
				/*	String name=selectedFile.getName();
					System.out.println(name.substring(name.lastIndexOf(".")+1));
					if((name.substring(name.lastIndexOf(".")+1)).equals("csv"))
					{
				*/	
					pathFile2.setText(selectedFile.getAbsolutePath());

					try {
						alFile2 = new ArrayList<String[]>();
						brFile2 = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
						while ((lineFile2 = brFile2.readLine()) != null) {
							// use space as separator
							String[] lineRecord = lineFile2.split(csvSplitBy);
							alFile2.add(lineRecord);

						}

					} catch (FileNotFoundException ex) {
						ex.printStackTrace();
					} catch (IOException ex) {
						ex.printStackTrace();
					} finally {
						if (brFile2 != null) {
							try {
								brFile2.close();
							} catch (IOException ex) {
								ex.printStackTrace();
							}
						}
					}
			/*	}else {
					JOptionPane.showMessageDialog(frameObj, "Selecte .csv file only");
				}
			*/		
				}
			}
		});

	
/*
 * @Adding ActionListener on Search Button.
 * @After clicking on Search Button it will check Everything is Selected or not. If not then it gives Pop up message
 * @ If everything is Selected then it will call searchFile1() and searchFile2() method. which will perform comparison and 
 *    show you result.		
 */
		searchDifference.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				if (pathFile1.getText() == "Select File-1" || pathFile2.getText() == "Select File-2") {
					JOptionPane.showMessageDialog(frameObj, "Select File ");
				} else {

					if (trainList.getSelectedItem().equals("Select...")) {
						JOptionPane.showMessageDialog(frameObj, "Select Train From List");
					} else {

						if (new CompareAction().SearchTrainInFile2()) {
							displayResultF1.setText("");
							displayResultF2.setText("");
							new CompareAction().searchFile1();
							new CompareAction().searchFile2();
						} else {

							JOptionPane.showMessageDialog(frameObj, "Selected Train Not Present In File-2");
						}

					}
				}

			}
		});

	}

	
	
/*
 * @CompareAction class is Inner Class having methods like SearchTrainInFile2(),TrainList(),calculateTimeDifference(String,String),
 *  searchFile1(),searchFile2(). 	
 */
	public class CompareAction {

		public boolean SearchTrainInFile2() {
			String trainNumber = (String) trainList.getSelectedItem();
			Iterator<String[]> it = alFile2.iterator();

			while (it.hasNext()) {
				String[] strings = (String[]) it.next();

				if (strings[0].equals(trainNumber)) {
					return true;

				}

			}

			return false;
		}

		public void TrainList() {

			trainListFile1 = new ArrayList<String>();
			trainListFile1.add("Select...");
			Iterator<String[]> it = alFile1.iterator();
			while (it.hasNext()) {
				String[] strings = (String[]) it.next();

				trainListFile1.add(strings[0]);

			}

			String[] trainListF1 = trainListFile1.toArray(new String[trainListFile1.size()]);
			trainList.setModel(new DefaultComboBoxModel(trainListF1));
			trainList.setEnabled(true);
			trainList.setEditable(false);
			timeList.setSelectedIndex(1);
			timeList.setEnabled(true);

		}

		public String calculateTimeDifference(String sTime, String eTime) {
			int hh1, mm1, ss1, hh2, mm2, ss2;
			int hh3 = 00, mm3 = 00, ss3 = 00;
			hh1 = Integer.valueOf(sTime.substring(0, 2));
			mm1 = Integer.valueOf(sTime.substring(2, 4));
			ss1 = Integer.valueOf(sTime.substring(4, 6));
			System.out.println("HH1-" + hh1 + " MM1-" + mm1 + " ss1-" + ss1);
			hh2 = Integer.valueOf(eTime.substring(0, 2));
			mm2 = Integer.valueOf(eTime.substring(2, 4));
			ss2 = Integer.valueOf(eTime.substring(4, 6));
			System.out.println("HH2-" + hh2 + " MM2-" + mm2 + " ss2-" + ss2);

			if (ss2 < ss1 || ss2 == ss2 || ss2 > ss1) {
				if (ss2 == ss1) {
					ss3 = 00;

				}
				if (ss2 > ss1) {
					ss3 = ss2 - ss1;

				}
				if (ss2 < ss1) {
					mm2--;
					ss2 += 60;
					ss3 = ss2 - ss1;

				}
			}
			if (mm2 < mm1 || mm2 == mm1 || mm2 > mm1) {
				if (mm2 == mm1) {
					mm3 = 00;
				}
				if (mm2 > mm1) {
					mm3 = mm2 - mm1;
				}
				if (mm2 < mm1) {
					hh2--;
					mm2 += 60;
					mm3 = mm2 - mm1;
				}

			}
			if (hh2 == hh1 || hh2 > hh1) {

				if (hh1 == hh2) {
					hh3 = 00;
				}
				if (hh2 > hh1) {
					hh3 = hh2 - hh1;
				}

		
			}

	

			return hh3 + ":" + mm3 + ":" + ss3;

		}

		public void searchFile1() {
			displayResultF1.append("\t\t\tFile-1 \n\n");

			displayResultF1.append("Loop Number\t\t" + "Arrival Time\t\t" + "Depature Time\t"
					+ "            Halt Time(HH:MM:SS)" + "\n");
			String trainNumber = (String) trainList.getSelectedItem();
			int timedifference = Integer.valueOf((String) timeList.getSelectedItem());

			Iterator<String[]> it = alFile1.iterator();
			while (it.hasNext()) {
				String[] strings = (String[]) it.next();

				if (strings[0].equals(trainNumber)) {

					for (int j = 9; j < strings.length; j += 3) {

						resultString = new CompareAction().calculateTimeDifference(strings[j + 1], strings[j + 2]);
						int hour = 0, minute = 0, second = 0;
						String[] timeResult = resultString.split(":");

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);
								System.out.println("Hours ******* " + hour);
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						if (hour >= 0 || minute >= 0) {
							if (hour > 0) {

								displayResultF1.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" + strings[j + 2]
										+ "\t\t" + hour + ":" + minute + ":" + second + "\n");

							}
							if (minute >= timedifference) {
								displayResultF1.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" + strings[j + 2]
										+ "\t\t" + hour + ":" + minute + ":" + second + "\n");
							}

						}

					}

					break;
				}

			}
			return;

		}

		public void searchFile2() {

			displayResultF2.append("\t\t\tFile-2 \n\n");
			displayResultF2.append("Loop Number\t\t" + "Arrival Time\t\t" + "Depature Time\t"
					+ "            Halt Time(HH:MM:SS)" + "\n");

			String trainNumber = (String) trainList.getSelectedItem();
			int timedifference = Integer.valueOf((String) timeList.getSelectedItem());

			Iterator<String[]> it = alFile2.iterator();
			while (it.hasNext()) {

				String[] strings = (String[]) it.next();

				if (strings[0].equals(trainNumber)) {

					for (int j = 9; j < strings.length; j += 3) {

						resultString = new CompareAction().calculateTimeDifference(strings[j + 1], strings[j + 2]);
						String[] timeResult = resultString.split(":");
						int hour = 0, minute = 0, second = 0;

						// Checking String is null or not
						if (timeResult[0].equals("0")) {
							if (timeResult[0].equals("0")) {

								hour = 0;
								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);
									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}

								}

							}

							else {
								hour = Integer.parseInt(timeResult[0]);

								if (timeResult[1].equals("0")) {
									minute = 0;
									if (timeResult[2].equals("0")) {
										second = 0;
									}
								} else {
									minute = Integer.parseInt(timeResult[1]);

									if (timeResult[2].equals("0")) {
										second = 0;
									} else {
										second = Integer.parseInt(timeResult[2]);
									}
								}

							}

						} else {

							hour = Integer.parseInt(timeResult[0]);
							if (timeResult[1].equals("0")) {
								minute = 0;
								if (timeResult[2].equals("0")) {
									second = 0;
								}
							} else {
								minute = Integer.parseInt(timeResult[1]);

								if (timeResult[2].equals("0")) {
									second = 0;
								} else {
									second = Integer.parseInt(timeResult[2]);
								}
							}

						}

						if (hour >= 0 || minute >= 0) {
							if (hour > 0) {

								displayResultF2.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" + strings[j + 2]
										+ "\t\t" + hour + ":" + minute + ":" + second + "\n");

							}
							if (minute >= timedifference) {
								displayResultF2.append(strings[j] + "\t\t" + strings[j + 1] + "\t\t" + strings[j + 2]
										+ "\t\t" + hour + ":" + minute + ":" + second + "\n");
							}

						}

					}

					break;
				}

			}
			return;

		}

	}

	public static void main(String[] args) {
		new CompareTrainsByTime();

	}

}
